// Runs synchronously in <head> (before first paint) so there is no light/dark flash.
(function () {
  var theme = 'light';
  try {
    var saved = localStorage.getItem('smart-todo-theme');
    if (saved === 'dark' || saved === 'light') theme = saved;
    else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) theme = 'dark';
  } catch (e) {
    /* localStorage blocked: fall back to light */
  }
  document.documentElement.setAttribute('data-theme', theme);
})();

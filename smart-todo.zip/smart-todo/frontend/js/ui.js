// Shared UI helpers: DOM builder, inline SVG icons, toasts, dialogs, form errors, dates.
// Everything is built with createElement/textContent (never innerHTML), so user data cannot inject markup.

const SVG_NS = 'http://www.w3.org/2000/svg';

/* ------------------------------------------------------------ DOM builder */
const PROPS = new Set(['value', 'checked', 'disabled', 'selected', 'hidden', 'readOnly']);

/** h('div', {class:'x', onclick: fn}, child, 'text', [more]) */
export function h(tag, props, ...children) {
  const el = document.createElement(tag);
  Object.entries(props || {}).forEach(([key, val]) => {
    if (val === null || val === undefined || val === false) return;
    if (key === 'class') el.className = val;
    else if (key === 'text') el.textContent = val;
    else if (key === 'dataset') Object.assign(el.dataset, val);
    else if (key.startsWith('on') && typeof val === 'function') {
      el.addEventListener(key.slice(2).toLowerCase(), val);
    } else if (PROPS.has(key)) el[key] = val;
    else el.setAttribute(key, val === true ? '' : String(val));
  });
  append(el, children);
  return el;
}

function append(el, children) {
  children.forEach((c) => {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) append(el, c);
    else el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  });
}

/** SVG element builder for charts. */
export function s(tag, attrs, ...children) {
  const el = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => el.setAttribute(k, String(v)));
  append(el, children);
  return el;
}

/* ----------------------------------------------------------------- icons */
const ICONS = {
  logo: ['M9 11l3 3L22 4', 'M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'],
  plus: ['M12 5v14', 'M5 12h14'],
  search: [{ circle: [11, 11, 7] }, 'M21 21l-4.3-4.3'],
  edit: ['M12 20h9', 'M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z'],
  trash: [
    'M3 6h18',
    'M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6',
    'M10 11v6',
    'M14 11v6',
    'M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2',
  ],
  check: ['M20 6L9 17l-5-5'],
  checks: ['M18 6L7 17l-5-5', 'M22 10l-7.5 7.5L13 16'],
  x: ['M18 6L6 18', 'M6 6l12 12'],
  sun: [
    { circle: [12, 12, 4] },
    'M12 2v2',
    'M12 20v2',
    'M4.9 4.9l1.4 1.4',
    'M17.7 17.7l1.4 1.4',
    'M2 12h2',
    'M20 12h2',
    'M4.9 19.1l1.4-1.4',
    'M17.7 6.3l1.4-1.4',
  ],
  moon: ['M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z'],
  download: ['M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4', 'M7 10l5 5 5-5', 'M12 15V3'],
  logout: ['M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4', 'M16 17l5-5-5-5', 'M21 12H9'],
  repeat: ['M17 1l4 4-4 4', 'M3 11V9a4 4 0 0 1 4-4h14', 'M7 23l-4-4 4-4', 'M21 13v2a4 4 0 0 1-4 4H3'],
  calendar: [{ rect: [3, 4, 18, 18, 2] }, 'M16 2v4', 'M8 2v4', 'M3 10h18'],
  folder: ['M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z'],
  'arrow-up': ['M12 19V5', 'M5 12l7-7 7 7'],
  'chevron-left': ['M15 18l-6-6 6-6'],
  'chevron-right': ['M9 18l6-6-6-6'],
  alert: [
    'M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z',
    'M12 9v4',
    'M12 17h.01',
  ],
  info: [{ circle: [12, 12, 10] }, 'M12 16v-4', 'M12 8h.01'],
  inbox: [
    'M22 12h-6l-2 3h-4l-2-3H2',
    'M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z',
  ],
  edit2: ['M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34', 'M18 2l4 4-10 10H8v-4L18 2z'],
};

export function icon(name, size = 18) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', String(size));
  svg.setAttribute('height', String(size));
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '2');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.setAttribute('class', 'icon');
  (ICONS[name] || []).forEach((part) => {
    let node;
    if (typeof part === 'string') {
      node = document.createElementNS(SVG_NS, 'path');
      node.setAttribute('d', part);
    } else if (part.circle) {
      node = document.createElementNS(SVG_NS, 'circle');
      ['cx', 'cy', 'r'].forEach((k, i) => node.setAttribute(k, String(part.circle[i])));
    } else if (part.rect) {
      node = document.createElementNS(SVG_NS, 'rect');
      ['x', 'y', 'width', 'height', 'rx'].forEach((k, i) => node.setAttribute(k, String(part.rect[i])));
    }
    if (node) svg.append(node);
  });
  return svg;
}

/** Replaces <span data-icon="name" data-size="18"> placeholders with inline SVG. */
export function hydrateIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach((el) => {
    el.replaceWith(icon(el.dataset.icon, Number(el.dataset.size) || 18));
  });
}

/* ----------------------------------------------------------------- theme */
export function initThemeToggle(btn) {
  const render = () => {
    const dark = document.documentElement.dataset.theme === 'dark';
    btn.replaceChildren(icon(dark ? 'sun' : 'moon', 18));
    const label = dark ? 'Switch to light mode' : 'Switch to dark mode';
    btn.setAttribute('aria-label', label);
    btn.title = label;
  };
  render();
  btn.addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try {
      localStorage.setItem('smart-todo-theme', next);
    } catch (_) {
      /* storage blocked: the choice just will not persist */
    }
    render();
  });
}

/* ---------------------------------------------------------------- toasts */
let toastHost = null;

export function toast(message, type = 'info', ms) {
  if (!toastHost) {
    toastHost = h('div', { class: 'toasts', 'aria-live': 'polite', 'aria-label': 'Notifications' });
    document.body.append(toastHost);
  }
  const iconName = type === 'success' ? 'check' : type === 'error' ? 'alert' : 'info';
  let timer;
  const el = h(
    'div',
    { class: `toast toast-${type}`, role: type === 'error' ? 'alert' : 'status' },
    icon(iconName, 18),
    h('span', { class: 'toast-msg', text: message }),
    h(
      'button',
      { class: 'toast-close', type: 'button', 'aria-label': 'Dismiss notification', onclick: () => dismiss() },
      icon('x', 14)
    )
  );
  const dismiss = () => {
    clearTimeout(timer);
    el.remove();
  };
  toastHost.append(el);
  timer = setTimeout(dismiss, ms || (type === 'error' ? 7000 : 4000));
}

/* --------------------------------------------------------------- dialogs */
/** Closes a dialog when the backdrop (not its content) is clicked. */
export function initDialogs() {
  document.querySelectorAll('dialog').forEach((dlg) => {
    let downOnBackdrop = false;
    dlg.addEventListener('mousedown', (e) => {
      downOnBackdrop = e.target === dlg;
    });
    dlg.addEventListener('click', (e) => {
      if (e.target === dlg && downOnBackdrop) dlg.close('cancel');
    });
  });
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-close]');
    if (btn) btn.closest('dialog').close('cancel');
  });
}

/** Promise-based confirm dialog. Resolves true only when the confirm button is used. */
export function confirmDialog({ title, message, confirmText = 'Confirm', danger = true }) {
  const dlg = document.getElementById('confirm-dialog');
  dlg.querySelector('#confirm-title').textContent = title;
  dlg.querySelector('#confirm-message').textContent = message;
  const ok = dlg.querySelector('#confirm-ok');
  ok.textContent = confirmText;
  ok.className = `btn ${danger ? 'btn-danger' : 'btn-primary'}`;
  dlg.returnValue = '';
  return new Promise((resolve) => {
    dlg.addEventListener('close', () => resolve(dlg.returnValue === 'confirm'), { once: true });
    dlg.showModal();
  });
}

/* ------------------------------------------------------- forms & buttons */
export function setBusy(btn, busy) {
  btn.disabled = busy;
  btn.classList.toggle('is-busy', busy);
  btn.setAttribute('aria-busy', String(busy));
}

export function clearErrors(form) {
  form.querySelectorAll('[data-error-for]').forEach((p) => {
    p.hidden = true;
    p.textContent = '';
  });
  form.querySelectorAll('[aria-invalid]').forEach((i) => i.removeAttribute('aria-invalid'));
  const alertBox = form.querySelector('[data-form-error]');
  if (alertBox) {
    alertBox.hidden = true;
    alertBox.textContent = '';
  }
}

/**
 * Shows per-field messages ({ field: message }) next to their inputs and focuses the first one.
 * Messages for fields without an input, plus `formMessage`, go into the form-level alert.
 */
export function showErrors(form, errors, formMessage) {
  const loose = [];
  let first = null;
  Object.entries(errors || {}).forEach(([name, message]) => {
    const p = form.querySelector(`[data-error-for="${name}"]`);
    const input = form.elements[name];
    if (!p) {
      loose.push(message);
      return;
    }
    p.textContent = message;
    p.hidden = false;
    if (input && input.setAttribute) {
      input.setAttribute('aria-invalid', 'true');
      if (p.id) input.setAttribute('aria-describedby', p.id);
    }
    if (!first) first = input || null;
  });
  if (formMessage) loose.unshift(formMessage);
  const alertBox = form.querySelector('[data-form-error]');
  if (alertBox && loose.length) {
    alertBox.textContent = loose.join(' ');
    alertBox.hidden = false;
  }
  if (first && first.focus) first.focus();
}

/* ----------------------------------------------------------------- dates */
const pad = (n) => String(n).padStart(2, '0');

/** Local calendar date as YYYY-MM-DD. */
export function todayStr(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function parseYmd(str) {
  const [y, m, d] = str.split('-').map(Number);
  return new Date(y, m - 1, d);
}

/** Whole days from date string a to date string b (b - a). */
export function diffDays(a, b) {
  const [ay, am, ad] = a.split('-').map(Number);
  const [by, bm, bd] = b.split('-').map(Number);
  return Math.round((Date.UTC(by, bm - 1, bd) - Date.UTC(ay, am - 1, ad)) / 86400000);
}

export function formatDay(str, { weekday = true } = {}) {
  const d = parseYmd(str);
  return d.toLocaleDateString(undefined, {
    weekday: weekday ? 'short' : undefined,
    day: 'numeric',
    month: 'short',
    year: d.getFullYear() === new Date().getFullYear() ? undefined : 'numeric',
  });
}

/** Label and tone for a task's due date, or null when it has none. */
export function dueInfo(task, today) {
  if (!task.due_date) return null;
  if (task.is_completed) return { text: formatDay(task.due_date), tone: 'done' };
  const d = diffDays(today, task.due_date);
  if (d < 0) return { text: d === -1 ? 'Overdue by 1 day' : `Overdue by ${-d} days`, tone: 'overdue' };
  if (d === 0) return { text: 'Due today', tone: 'today' };
  if (d === 1) return { text: 'Due tomorrow', tone: 'soon' };
  return { text: formatDay(task.due_date), tone: 'normal' };
}

export const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);

// Dashboard: stats + charts, task list, dialogs, shortcuts.
import { api, ApiError, qs } from './api.js';
import {
  h, s, icon, hydrateIcons, toast, confirmDialog, setBusy, clearErrors, showErrors,
  initThemeToggle, initDialogs, todayStr, parseYmd, formatDay, dueInfo, capitalize,
} from './ui.js';

const $ = (sel, root = document) => root.querySelector(sel);
const PAGE_SIZE = 9;
const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const DEFAULT_FILTERS = { q: '', priority: '', status: '', category: '', due: '', sort: 'due_date', order: 'asc' };

const state = {
  user: null,
  categories: [],
  tasks: [],
  pagination: { page: 1, limit: PAGE_SIZE, total: 0, totalPages: 1 },
  stats: null,
  filters: { ...DEFAULT_FILTERS },
  page: 1,
  listSeq: 0,
  statsSeq: 0,
  loaded: false,
  openChecklists: new Set(),
  pendingFocus: null,
};

const handleError = (err) => {
  if (err instanceof ApiError && err.status === 401) return; // api() is already redirecting
  toast(err.message || 'Something went wrong.', 'error');
};

const hasActiveFilters = () => Object.keys(DEFAULT_FILTERS).some(
  (k) => k !== 'sort' && k !== 'order' && state.filters[k] !== DEFAULT_FILTERS[k]
);

const listParams = (extra = {}) => ({
  q: state.filters.q.trim(),
  priority: state.filters.priority,
  status: state.filters.status,
  category: state.filters.category,
  due: state.filters.due,
  sort: state.filters.sort,
  order: state.filters.order,
  today: todayStr(),
  ...extra,
});

/* ======================================================================
   Data loading
   ====================================================================== */
async function loadTasks() {
  const seq = ++state.listSeq;
  const grid = $('#task-grid');
  grid.setAttribute('aria-busy', 'true');
  if (!state.loaded) renderSkeleton();
  else grid.classList.add('is-loading');
  try {
    const data = await api('GET', `/tasks?${qs(listParams({ page: state.page, limit: PAGE_SIZE }))}`);
    if (seq !== state.listSeq) return; // a newer request superseded this one
    state.tasks = data.tasks;
    state.pagination = data.pagination;
    state.page = data.pagination.page;
    state.loaded = true;
    renderTasks();
  } catch (err) {
    if (seq !== state.listSeq) return;
    renderLoadError(err);
  } finally {
    if (seq === state.listSeq) {
      grid.setAttribute('aria-busy', 'false');
      grid.classList.remove('is-loading');
    }
  }
}

async function loadStats() {
  const seq = ++state.statsSeq;
  try {
    const data = await api('GET', `/stats?${qs({ today: todayStr(), tz: -new Date().getTimezoneOffset() })}`);
    if (seq !== state.statsSeq) return;
    state.stats = data;
    renderStats();
  } catch (err) {
    handleError(err);
  }
}

async function loadCategories() {
  const data = await api('GET', '/categories');
  state.categories = data.categories;
  renderCategoryFilter();
}

const refresh = () => Promise.all([loadTasks(), loadStats()]);

/* ======================================================================
   Header, stats, charts
   ====================================================================== */
function renderHeader() {
  const name = state.user.name;
  const hour = new Date().getHours();
  const part = hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';
  $('#greeting').textContent = `Good ${part}, ${name.split(' ')[0]}`;
  $('#hero-date').textContent = new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
  $('#avatar').textContent = name.trim().charAt(0).toUpperCase();
  $('#account-name').textContent = name;
}

function renderStats() {
  const { totals, completionRate, last7Days, priority, upNext } = state.stats;
  Object.entries(totals).forEach(([key, value]) => {
    const el = $(`#stat-${key}`);
    if (el) el.textContent = String(value);
  });

  const sub = $('#hero-sub');
  if (totals.total === 0) sub.textContent = 'Add your first task to get started.';
  else if (totals.pending === 0) sub.textContent = 'Everything is done. Nice work.';
  else {
    const bits = [`${totals.pending} open ${totals.pending === 1 ? 'task' : 'tasks'}`];
    if (totals.dueToday) bits.push(`${totals.dueToday} due today`);
    if (totals.overdue) bits.push(`${totals.overdue} overdue`);
    sub.textContent = bits.join(', ');
  }

  renderDonut(completionRate, totals);
  renderBars(last7Days);
  renderPriority(priority);
  renderUpNext(upNext);
}

function renderDonut(rate, totals) {
  const R = 54;
  const C = 2 * Math.PI * R;
  const value = s('circle', {
    cx: 70, cy: 70, r: R, class: 'donut-value', transform: 'rotate(-90 70 70)',
    'stroke-dasharray': C.toFixed(2), 'stroke-dashoffset': C.toFixed(2),
  });
  const svg = s(
    'svg',
    { viewBox: '0 0 140 140', class: 'donut', role: 'img', 'aria-label': `${rate}% complete: ${totals.completed} of ${totals.total} tasks done` },
    s('circle', { cx: 70, cy: 70, r: R, class: 'donut-track' }),
    value,
    s('text', { x: 70, y: 74, 'text-anchor': 'middle', class: 'donut-pct' }, `${rate}%`),
    s('text', { x: 70, y: 92, 'text-anchor': 'middle', class: 'donut-sub' }, 'complete')
  );
  $('#donut').replaceChildren(
    h('div', { class: 'donut-wrap' }, svg,
      h('ul', { class: 'legend' },
        h('li', {}, h('span', { class: 'dot' }), `${totals.completed} done`),
        h('li', {}, h('span', { class: 'dot dot-open' }), `${totals.pending} pending`)))
  );
  const target = (C * (1 - rate / 100)).toFixed(2);
  requestAnimationFrame(() => requestAnimationFrame(() => { value.style.strokeDashoffset = target; }));
}

function renderBars(days) {
  const W = 320, base = 126, maxH = 98, step = (W - 16) / 7, bw = 26;
  const max = Math.max(1, ...days.map((d) => d.count));
  const today = todayStr();
  const nodes = [];
  days.forEach((d, i) => {
    const x = 8 + i * step + (step - bw) / 2;
    const hgt = d.count ? Math.max(6, (d.count / max) * maxH) : 0;
    nodes.push(
      d.count
        ? s('rect', { x: x.toFixed(1), y: (base - hgt).toFixed(1), width: bw, height: hgt.toFixed(1), rx: 5, class: `bar${d.date === today ? ' bar-today' : ''}` })
        : s('rect', { x: x.toFixed(1), y: base - 2, width: bw, height: 2, rx: 1, class: 'bar-zero' })
    );
    if (d.count) nodes.push(s('text', { x: (x + bw / 2).toFixed(1), y: (base - hgt - 5).toFixed(1), class: 'bar-val' }, String(d.count)));
    nodes.push(s('text', { x: (x + bw / 2).toFixed(1), y: 144, class: 'bar-day' },
      parseYmd(d.date).toLocaleDateString(undefined, { weekday: 'short' })));
  });
  const label = 'Tasks completed per day: ' + days.map((d) => `${formatDay(d.date)} ${d.count}`).join(', ');
  const total = days.reduce((n, d) => n + d.count, 0);
  $('#bars').replaceChildren(
    s('svg', { viewBox: `0 0 ${W} 152`, class: 'bars', role: 'img', 'aria-label': label }, ...nodes),
    total === 0 ? h('p', { class: 'chart-note', text: 'Nothing completed this week yet.' }) : null
  );
}

function renderPriority(priority) {
  const max = Math.max(1, ...Object.values(priority).map((p) => p.total));
  const rows = ['High', 'Medium', 'Low'].map((name) => {
    const p = priority[name];
    const done = h('span', { class: 'bar-done' });
    const open = h('span', { class: 'bar-open' });
    done.style.width = `${(p.completed / max) * 100}%`;
    open.style.width = `${((p.total - p.completed) / max) * 100}%`;
    return h('li', { class: `prio-${name.toLowerCase()}` },
      h('div', { class: 'prio-row-head' }, h('span', { text: name }), h('span', { text: `${p.total - p.completed} open, ${p.completed} done` })),
      h('div', { class: 'bar-track', role: 'img', 'aria-label': `${name} priority: ${p.total - p.completed} open, ${p.completed} done` }, done, open));
  });
  $('#priority').replaceChildren(h('ul', { class: 'prio-rows' }, rows));
}

function renderUpNext(items) {
  const host = $('#upnext');
  if (!items.length) {
    host.replaceChildren(h('p', { class: 'muted small', text: 'Nothing scheduled. Give a task a due date and it will show up here.' }));
    return;
  }
  const today = todayStr();
  const list = h('ol', { class: 'upnext-list' });
  items.forEach((it) => {
    const d = parseYmd(it.due_date);
    const info = dueInfo({ due_date: it.due_date, is_completed: false }, today);
    const when = ['overdue', 'today', 'soon'].includes(info.tone)
      ? info.text : d.toLocaleDateString(undefined, { weekday: 'long' });
    const meta = [when, it.category && it.category.name, `${it.priority} priority`].filter(Boolean).join(', ');
    list.append(h('li', {},
      h('button', { type: 'button', class: `upnext-item tone-${info.tone}`, onclick: () => openTaskById(it.id) },
        h('span', { class: 'date-tile', 'aria-hidden': 'true' },
          h('span', { class: 'date-day', text: String(d.getDate()) }),
          h('span', { class: 'date-mon', text: d.toLocaleDateString(undefined, { month: 'short' }) })),
        h('span', { class: 'upnext-text' },
          h('span', { class: 'upnext-title', text: it.title }),
          h('span', { class: 'upnext-meta', text: meta })))));
  });
  host.replaceChildren(list);
}

/* ======================================================================
   Task list
   ====================================================================== */
function renderSkeleton() {
  $('#task-grid').replaceChildren(...Array.from({ length: 6 }, () =>
    h('div', { class: 'task-card skeleton', 'aria-hidden': 'true' },
      h('div', { class: 'line w-60' }), h('div', { class: 'line w-35' }), h('div', { class: 'line w-90' }))));
  $('#results-meta').textContent = 'Loading tasks...';
  $('#pagination').replaceChildren();
}

function renderLoadError(err) {
  $('#results-meta').textContent = '';
  $('#task-grid').replaceChildren(
    h('div', { class: 'empty', role: 'alert' }, icon('alert', 40),
      h('h3', { text: 'Could not load your tasks' }),
      h('p', { text: err.message }),
      h('button', { class: 'btn btn-primary', type: 'button', onclick: () => loadTasks() }, 'Try again'))
  );
}

function renderTasks() {
  const grid = $('#task-grid');
  grid.replaceChildren();
  const { total, page, limit } = state.pagination;

  if (state.tasks.length === 0) {
    $('#results-meta').textContent = '';
    grid.append(hasActiveFilters() ? emptyFiltered() : emptyNoTasks());
    renderPagination();
    return;
  }
  const from = (page - 1) * limit + 1;
  $('#results-meta').textContent =
    `Showing ${from}-${from + state.tasks.length - 1} of ${total} ${total === 1 ? 'task' : 'tasks'}${hasActiveFilters() ? ' (filtered)' : ''}`;
  state.tasks.forEach((t) => grid.append(taskCard(t)));
  renderPagination();

  if (state.pendingFocus) {
    const target = grid.querySelector(`[data-id="${state.pendingFocus.id}"] ${state.pendingFocus.sel}`);
    if (target) target.focus();
    state.pendingFocus = null;
  }
}

const emptyNoTasks = () => h('div', { class: 'empty' }, icon('inbox', 44),
  h('h3', { text: 'No tasks yet' }),
  h('p', { text: 'Add your first task. Give it a due date and it will appear under "Up next".' }),
  h('button', { class: 'btn btn-primary', type: 'button', onclick: () => openTaskDialog() }, icon('plus', 16), 'Add a task'));

const emptyFiltered = () => h('div', { class: 'empty' }, icon('search', 44),
  h('h3', { text: 'No tasks match these filters' }),
  h('p', { text: 'Try a different search or clear the filters to see everything.' }),
  h('button', { class: 'btn btn-ghost', type: 'button', onclick: clearFilters }, 'Clear filters'));

function categoryChip(cat) {
  const sw = h('span', { class: 'swatch', 'aria-hidden': 'true' });
  sw.style.setProperty('--c', cat.color);
  return h('span', { class: 'badge badge-cat' }, sw, cat.name);
}

function taskCard(t) {
  const due = dueInfo(t, todayStr());
  const check = h('input', {
    type: 'checkbox', class: 'task-check', checked: t.is_completed,
    'aria-label': `${t.is_completed ? 'Mark as pending' : 'Mark as completed'}: ${t.title}`,
    onchange: (e) => toggleTask(t, e.target),
  });

  const badges = h('div', { class: 'badges' },
    h('span', { class: `badge prio prio-${t.priority.toLowerCase()}`, text: `${t.priority} priority` }),
    t.category && categoryChip(t.category),
    due && h('span', { class: `badge due-${due.tone}` }, icon('calendar', 13), due.text),
    t.recurrence !== 'none' && h('span', { class: 'badge' }, icon('repeat', 13), capitalize(t.recurrence)));

  let checklist = null;
  if (t.subtask_total > 0) {
    const pct = Math.round((t.subtask_done / t.subtask_total) * 100);
    const fill = h('span', { class: 'progress-fill' });
    fill.style.width = `${pct}%`;
    const details = h('details', {
      class: 'subtask-details', open: state.openChecklists.has(t.id),
      ontoggle: (e) => (e.target.open ? state.openChecklists.add(t.id) : state.openChecklists.delete(t.id)),
    },
      h('summary', {}, 'Checklist'),
      h('ul', { class: 'subtask-list' }, t.subtasks.map((sub) => h('li', {},
        h('label', { class: 'check check-sm' },
          h('input', { type: 'checkbox', checked: sub.is_completed, onchange: (e) => toggleSubtask(t, sub, e.target) }),
          h('span', { class: 'check-box', 'aria-hidden': 'true' }, icon('check', 12)),
          h('span', { class: `sub-title${sub.is_completed ? ' is-done' : ''}`, text: sub.title }))))));
    checklist = h('div', {},
      h('div', { class: 'progress-row' },
        h('div', {
          class: `progress${pct === 100 ? ' is-full' : ''}`, role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '100',
          'aria-valuenow': String(pct), 'aria-label': `Checklist progress for ${t.title}`,
        }, fill),
        h('span', { class: 'progress-text', text: `${t.subtask_done}/${t.subtask_total}` })),
      details);
  }

  return h('article', { class: `task-card prio-${t.priority.toLowerCase()}${t.is_completed ? ' is-done' : ''}`, dataset: { id: t.id } },
    h('div', { class: 'task-top' },
      h('label', { class: 'check' }, check, h('span', { class: 'check-box', 'aria-hidden': 'true' }, icon('check', 15))),
      h('div', { class: 'task-body' },
        h('h3', { class: 'task-title', text: t.title }),
        badges,
        t.description && h('p', { class: 'task-desc', text: t.description })),
      h('div', { class: 'task-actions' },
        h('button', { type: 'button', class: 'btn btn-ghost btn-icon btn-sm', title: 'Edit task', 'aria-label': `Edit: ${t.title}`, onclick: () => openTaskDialog(t) }, icon('edit', 16)),
        h('button', { type: 'button', class: 'btn btn-ghost btn-icon btn-sm', title: 'Delete task', 'aria-label': `Delete: ${t.title}`, onclick: () => deleteTask(t) }, icon('trash', 16)))),
    checklist);
}

function renderPagination() {
  const nav = $('#pagination');
  nav.replaceChildren();
  const { page, totalPages } = state.pagination;
  if (totalPages <= 1) return;
  const go = (p) => { state.page = p; loadTasks(); $('#tasks-section').scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth' }); };
  const btn = (label, p, { disabled, current, aria } = {}) => h('button', {
    type: 'button', class: `page-btn${current ? ' is-current' : ''}`, disabled,
    'aria-label': aria, 'aria-current': current ? 'page' : null, onclick: () => go(p),
  }, label);

  nav.append(btn(icon('chevron-left', 18), page - 1, { disabled: page <= 1, aria: 'Previous page' }));
  const pages = new Set([1, totalPages, page - 1, page, page + 1]);
  let last = 0;
  [...pages].filter((p) => p >= 1 && p <= totalPages).sort((a, b) => a - b).forEach((p) => {
    if (p - last > 1) nav.append(h('span', { class: 'page-gap', 'aria-hidden': 'true', text: '...' }));
    nav.append(btn(String(p), p, { current: p === page, aria: `Page ${p}` }));
    last = p;
  });
  nav.append(btn(icon('chevron-right', 18), page + 1, { disabled: page >= totalPages, aria: 'Next page' }));
}

/* ======================================================================
   Task actions
   ====================================================================== */
async function toggleTask(t, input) {
  input.disabled = true;
  try {
    const res = await api('PATCH', `/tasks/${t.id}/status`, { completed: input.checked, today: todayStr() });
    state.pendingFocus = { id: t.id, sel: '.task-check' };
    if (res.task.is_completed) {
      toast(res.next_task ? `Done. The next repeat is due ${formatDay(res.next_task.due_date)}.` : 'Task completed.', 'success');
    } else toast('Moved back to pending.', 'info');
    await refresh();
  } catch (err) {
    input.checked = !input.checked;
    input.disabled = false;
    handleError(err);
  }
}

async function toggleSubtask(t, sub, input) {
  input.disabled = true;
  try {
    await api('PATCH', `/tasks/${t.id}/subtasks/${sub.id}`, { completed: input.checked });
    await refresh();
  } catch (err) {
    input.checked = !input.checked;
    input.disabled = false;
    handleError(err);
  }
}

async function deleteTask(t) {
  const ok = await confirmDialog({ title: 'Delete this task?', message: `"${t.title}" and its checklist will be permanently deleted.`, confirmText: 'Delete task' });
  if (!ok) return;
  try {
    await api('DELETE', `/tasks/${t.id}`);
    toast('Task deleted.', 'success');
    await Promise.all([refresh(), loadCategories()]);
  } catch (err) { handleError(err); }
}

async function clearCompleted(btn) {
  const n = state.stats ? state.stats.totals.completed : 0;
  if (!n) return toast('There are no completed tasks to clear.', 'info');
  const ok = await confirmDialog({
    title: 'Clear completed tasks?',
    message: `This permanently deletes ${n} completed ${n === 1 ? 'task' : 'tasks'}. It cannot be undone.`,
    confirmText: 'Delete completed',
  });
  if (!ok) return;
  setBusy(btn, true);
  try {
    const res = await api('DELETE', '/tasks/completed');
    toast(`Cleared ${res.deleted} completed ${res.deleted === 1 ? 'task' : 'tasks'}.`, 'success');
    await refresh();
  } catch (err) { handleError(err); } finally { setBusy(btn, false); }
}

async function exportCsv(btn) {
  setBusy(btn, true);
  try {
    const res = await fetch(`/api/tasks/export?${qs(listParams())}`, { credentials: 'same-origin' });
    if (res.status === 401) return window.location.replace('/login');
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new ApiError(res.status, data.error || 'Export failed.');
    }
    const url = URL.createObjectURL(await res.blob());
    const a = h('a', { href: url, download: `tasks-${todayStr()}.csv` });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    toast('Exported your current view to CSV.', 'success');
  } catch (err) { handleError(err); } finally { setBusy(btn, false); }
}

async function openTaskById(id) {
  try { openTaskDialog((await api('GET', `/tasks/${id}`)).task); } catch (err) { handleError(err); }
}

/* ======================================================================
   Filters
   ====================================================================== */
function renderCategoryFilter() {
  const sel = $('#f-category');
  const current = state.filters.category;
  sel.replaceChildren(
    h('option', { value: '', text: 'All categories' }),
    h('option', { value: 'none', text: 'No category' }),
    ...state.categories.map((c) => h('option', { value: String(c.id), text: c.name }))
  );
  sel.value = String(current);
  if (sel.value !== String(current)) { state.filters.category = ''; sel.value = ''; }
}

function syncFilterUi() {
  const f = state.filters;
  $('#search').value = f.q;
  $('#f-priority').value = f.priority;
  $('#f-status').value = f.status;
  $('#f-category').value = String(f.category);
  $('#f-due').value = f.due;
  $('#f-sort').value = f.sort;
  const desc = f.order === 'desc';
  const orderBtn = $('#sort-order');
  orderBtn.classList.toggle('is-desc', desc);
  const label = desc ? 'Sort order: descending. Switch to ascending' : 'Sort order: ascending. Switch to descending';
  orderBtn.setAttribute('aria-label', label);
  orderBtn.title = label;
  $('#clear-filters').hidden = !hasActiveFilters();
}

function applyFilters(patch, { scroll = false } = {}) {
  Object.assign(state.filters, patch);
  state.page = 1;
  syncFilterUi();
  loadTasks();
  if (scroll) $('#tasks-section').scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth' });
}

function clearFilters() {
  applyFilters({ ...DEFAULT_FILTERS, sort: state.filters.sort, order: state.filters.order });
}

function initFilters() {
  let timer;
  $('#search').addEventListener('input', (e) => {
    clearTimeout(timer);
    timer = setTimeout(() => applyFilters({ q: e.target.value }), 300);
  });
  $('#search').addEventListener('keydown', (e) => {
    if (e.key === 'Escape') e.target.blur();
  });
  [['#f-priority', 'priority'], ['#f-status', 'status'], ['#f-category', 'category'], ['#f-due', 'due']].forEach(([sel, key]) =>
    $(sel).addEventListener('change', (e) => applyFilters({ [key]: e.target.value })));
  $('#f-sort').addEventListener('change', (e) =>
    applyFilters({ sort: e.target.value, order: e.target.value === 'created' ? 'desc' : 'asc' }));
  $('#sort-order').addEventListener('click', () =>
    applyFilters({ order: state.filters.order === 'asc' ? 'desc' : 'asc' }));
  $('#clear-filters').addEventListener('click', clearFilters);

  const STAT_FILTERS = {
    total: {}, pending: { status: 'pending' }, completed: { status: 'completed' },
    dueToday: { due: 'today', status: 'pending' }, overdue: { due: 'overdue' },
  };
  document.querySelectorAll('[data-stat]').forEach((btn) =>
    btn.addEventListener('click', () =>
      applyFilters({ ...DEFAULT_FILTERS, ...STAT_FILTERS[btn.dataset.stat] }, { scroll: true })));
}

/* ======================================================================
   Task dialog
   ====================================================================== */
const taskDlg = $('#task-dialog');
const taskForm = $('#task-form');
let editingId = null;
let draftSubs = [];

function fillCategorySelect(select, selected) {
  select.replaceChildren(
    h('option', { value: '', text: 'No category' }),
    ...state.categories.map((c) => h('option', { value: String(c.id), text: c.name }))
  );
  select.value = selected ? String(selected) : '';
}

function renderDraftSubs() {
  $('#subtask-list').replaceChildren(...draftSubs.map((sub, i) => h('li', { class: 'draft-sub' },
    h('label', { class: 'check check-sm' },
      h('input', { type: 'checkbox', checked: sub.is_completed, 'aria-label': `Step ${i + 1} done`, onchange: (e) => { sub.is_completed = e.target.checked; } }),
      h('span', { class: 'check-box', 'aria-hidden': 'true' }, icon('check', 12))),
    h('input', { class: 'input input-sm', type: 'text', value: sub.title, maxlength: '150', 'aria-label': `Step ${i + 1} title`, oninput: (e) => { sub.title = e.target.value; } }),
    h('button', { type: 'button', class: 'btn btn-ghost btn-icon btn-sm', 'aria-label': `Remove step ${i + 1}`,
      onclick: () => { draftSubs.splice(i, 1); renderDraftSubs(); $('#new-subtask').focus(); } }, icon('x', 14)))));
}

function addDraftSubtask() {
  const input = $('#new-subtask');
  const title = input.value.trim();
  if (!title) return;
  if (draftSubs.length >= 30) return toast('A task can have at most 30 checklist items.', 'error');
  draftSubs.push({ id: null, title, is_completed: false });
  input.value = '';
  renderDraftSubs();
  input.focus();
}

function openTaskDialog(task = null) {
  editingId = task ? task.id : null;
  clearErrors(taskForm);
  taskForm.reset();
  const f = taskForm.elements;
  $('#task-dialog-title').textContent = task ? 'Edit task' : 'New task';
  $('#task-submit').textContent = task ? 'Save changes' : 'Add task';
  fillCategorySelect(f.category_id, task && task.category_id);
  f.title.value = task ? task.title : '';
  f.description.value = task ? task.description : '';
  f.priority.value = task ? task.priority : 'Medium';
  f.due_date.value = task && task.due_date ? task.due_date : '';
  f.recurrence.value = task ? task.recurrence : 'none';
  draftSubs = task ? task.subtasks.map((x) => ({ ...x })) : [];
  $('#new-subtask').value = '';
  renderDraftSubs();
  taskDlg.showModal();
  f.title.focus();
}

function initTaskForm() {
  $('#add-subtask').addEventListener('click', addDraftSubtask);
  $('#new-subtask').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); addDraftSubtask(); }
  });

  taskForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(taskForm);
    if ($('#new-subtask').value.trim()) addDraftSubtask();
    const f = taskForm.elements;
    const payload = {
      title: f.title.value.trim(),
      description: f.description.value.trim(),
      priority: f.priority.value,
      due_date: f.due_date.value || null,
      category_id: f.category_id.value ? Number(f.category_id.value) : null,
      recurrence: f.recurrence.value,
      subtasks: draftSubs.filter((x) => x.title.trim()).map((x) => ({ id: x.id, title: x.title.trim(), is_completed: x.is_completed })),
    };

    const errors = {};
    if (!payload.title) errors.title = 'Title is required.';
    if (payload.recurrence !== 'none' && !payload.due_date) errors.recurrence = 'Repeating tasks need a due date.';
    if (Object.keys(errors).length) return showErrors(taskForm, errors);

    const btn = $('#task-submit');
    setBusy(btn, true);
    try {
      await api(editingId ? 'PUT' : 'POST', editingId ? `/tasks/${editingId}` : '/tasks', payload);
      taskDlg.close();
      toast(editingId ? 'Task updated.' : 'Task added.', 'success');
      await Promise.all([refresh(), loadCategories()]);
    } catch (err) {
      showErrors(taskForm, err.errors, err.errors ? null : err.message);
    } finally { setBusy(btn, false); }
  });
}

/* ======================================================================
   Categories dialog
   ====================================================================== */
const catDlg = $('#category-dialog');
const catForm = $('#category-form');
let editingCatId = null;
const PRESETS = [
  ['#4263EB', 'Indigo'], ['#D6336C', 'Pink'], ['#0CA678', 'Teal'], ['#F76707', 'Orange'], ['#7048E8', 'Violet'],
  ['#2F9E44', 'Green'], ['#1098AD', 'Cyan'], ['#E03131', 'Red'], ['#F08C00', 'Amber'], ['#495057', 'Slate'],
];

function setCatColor(color) {
  catForm.elements.color.value = color.toLowerCase();
  $('#swatches').querySelectorAll('.swatch-btn').forEach((b) =>
    b.setAttribute('aria-pressed', String(b.dataset.color.toLowerCase() === color.toLowerCase())));
}

function resetCategoryForm() {
  editingCatId = null;
  clearErrors(catForm);
  catForm.reset();
  $('#category-form-title').textContent = 'Add a category';
  $('#cat-submit').textContent = 'Add category';
  $('#cat-cancel').hidden = true;
  setCatColor(PRESETS[0][0]);
}

function renderCategoryList() {
  const list = $('#category-list');
  if (!state.categories.length) {
    list.replaceChildren(h('li', { class: 'muted', text: 'No categories yet. Add one below.' }));
    return;
  }
  list.replaceChildren(...state.categories.map((c) => {
    const sw = h('span', { class: 'swatch', 'aria-hidden': 'true' });
    sw.style.setProperty('--c', c.color);
    return h('li', { class: 'category-item' }, sw,
      h('span', { class: 'category-name', text: c.name }),
      h('span', { class: 'category-count', text: `${c.task_count} ${c.task_count === 1 ? 'task' : 'tasks'}` }),
      h('button', { type: 'button', class: 'btn btn-ghost btn-icon btn-sm', 'aria-label': `Edit category ${c.name}`, title: 'Edit',
        onclick: () => {
          editingCatId = c.id; clearErrors(catForm);
          catForm.elements.name.value = c.name; setCatColor(c.color);
          $('#category-form-title').textContent = `Edit "${c.name}"`;
          $('#cat-submit').textContent = 'Save changes';
          $('#cat-cancel').hidden = false;
          catForm.elements.name.focus();
        } }, icon('edit', 16)),
      h('button', { type: 'button', class: 'btn btn-ghost btn-icon btn-sm', 'aria-label': `Delete category ${c.name}`, title: 'Delete', onclick: () => deleteCategory(c) }, icon('trash', 16)));
  }));
}

async function deleteCategory(c) {
  const ok = await confirmDialog({
    title: `Delete "${c.name}"?`,
    message: c.task_count ? `${c.task_count} ${c.task_count === 1 ? 'task keeps' : 'tasks keep'} existing but will have no category.` : 'This category is not used by any task.',
    confirmText: 'Delete category',
  });
  if (!ok) return;
  try {
    await api('DELETE', `/categories/${c.id}`);
    toast('Category deleted.', 'success');
    if (editingCatId === c.id) resetCategoryForm();
    await loadCategories();
    renderCategoryList();
    await refresh();
  } catch (err) { handleError(err); }
}

function initCategories() {
  const sw = $('#swatches');
  PRESETS.forEach(([color, name]) => {
    const b = h('button', { type: 'button', class: 'swatch-btn', 'aria-label': name, 'aria-pressed': 'false', dataset: { color }, onclick: () => setCatColor(color) });
    b.style.setProperty('--c', color);
    sw.append(b);
  });
  catForm.elements.color.addEventListener('input', (e) => setCatColor(e.target.value));
  $('#cat-cancel').addEventListener('click', resetCategoryForm);

  $('#categories-btn').addEventListener('click', async () => {
    resetCategoryForm();
    try { await loadCategories(); } catch (err) { return handleError(err); }
    renderCategoryList();
    catDlg.showModal();
  });

  catForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(catForm);
    const payload = { name: catForm.elements.name.value.trim(), color: catForm.elements.color.value };
    if (!payload.name) return showErrors(catForm, { name: 'Category name is required.' });
    const btn = $('#cat-submit');
    setBusy(btn, true);
    try {
      const wasEditing = editingCatId !== null;
      await api(wasEditing ? 'PUT' : 'POST', wasEditing ? `/categories/${editingCatId}` : '/categories', payload);
      toast(wasEditing ? 'Category updated.' : 'Category added.', 'success');
      resetCategoryForm();
      await loadCategories();
      renderCategoryList();
      if (wasEditing) await refresh();
    } catch (err) {
      showErrors(catForm, err.errors, err.errors ? null : err.message);
    } finally { setBusy(btn, false); }
  });
}

/* ======================================================================
   Account dialog + logout
   ====================================================================== */
function initAccount() {
  const dlg = $('#account-dialog');
  const profileForm = $('#profile-form');
  const pwForm = $('#password-form');

  $('#account-btn').addEventListener('click', () => {
    clearErrors(profileForm); clearErrors(pwForm); pwForm.reset();
    profileForm.elements.name.value = state.user.name;
    $('#acc-email').value = state.user.email;
    dlg.showModal();
  });

  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(profileForm);
    const btn = $('#profile-submit');
    setBusy(btn, true);
    try {
      const { user } = await api('PUT', '/auth/profile', { name: profileForm.elements.name.value.trim() });
      state.user = user;
      renderHeader();
      toast('Name updated.', 'success');
    } catch (err) { showErrors(profileForm, err.errors, err.errors ? null : err.message); } finally { setBusy(btn, false); }
  });

  pwForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(pwForm);
    const f = pwForm.elements;
    if (f.newPassword.value !== f.confirm.value) return showErrors(pwForm, { confirm: 'Passwords do not match.' });
    const btn = $('#password-submit');
    setBusy(btn, true);
    try {
      await api('PUT', '/auth/password', { currentPassword: f.currentPassword.value, newPassword: f.newPassword.value });
      pwForm.reset();
      toast('Password updated. Other devices were signed out.', 'success');
    } catch (err) { showErrors(pwForm, err.errors, err.errors ? null : err.message); } finally { setBusy(btn, false); }
  });

  $('#logout-btn').addEventListener('click', async (e) => {
    setBusy(e.currentTarget, true);
    try { await api('POST', '/auth/logout'); } catch (_) { /* leave anyway */ }
    window.location.replace('/login');
  });
}

/* ======================================================================
   Keyboard shortcuts: n = new task, / = search
   ====================================================================== */
function initShortcuts() {
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey || e.defaultPrevented) return;
    const t = e.target;
    if (t.closest && t.closest('input, textarea, select, [contenteditable="true"]')) return;
    if (document.querySelector('dialog[open]')) return;
    if (e.key === 'n' || e.key === 'N') { e.preventDefault(); openTaskDialog(); }
    else if (e.key === '/') { e.preventDefault(); $('#search').focus(); }
  });
}

/* ======================================================================
   Boot
   ====================================================================== */
async function init() {
  hydrateIcons();
  initThemeToggle($('#theme-toggle'));
  initDialogs();
  initFilters();
  initTaskForm();
  initCategories();
  initAccount();
  initShortcuts();
  $('#new-task-btn').addEventListener('click', () => openTaskDialog());
  $('#export-btn').addEventListener('click', (e) => exportCsv(e.currentTarget));
  $('#clear-completed-btn').addEventListener('click', (e) => clearCompleted(e.currentTarget));
  syncFilterUi();
  renderSkeleton();

  try {
    const [me] = await Promise.all([api('GET', '/auth/me'), loadCategories()]);
    state.user = me.user;
    renderHeader();
    syncFilterUi();
    await refresh();
  } catch (err) {
    handleError(err);
    renderLoadError(err);
  }
}

init();

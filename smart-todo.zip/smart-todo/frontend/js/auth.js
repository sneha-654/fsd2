// Login and register pages.
import { api } from './api.js';
import { hydrateIcons, initThemeToggle, setBusy, clearErrors, showErrors } from './ui.js';

hydrateIcons();
initThemeToggle(document.getElementById('theme-toggle'));

// Show / hide password buttons
document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const input = document.getElementById(btn.getAttribute('aria-controls'));
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.textContent = show ? 'Hide' : 'Show';
    btn.setAttribute('aria-pressed', String(show));
  });
});

/** Same rules as the server (the server is still the authority). */
function passwordProblem(pw) {
  if (pw.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Za-z]/.test(pw)) return 'Password must contain at least one letter.';
  if (!/\d/.test(pw)) return 'Password must contain at least one number.';
  return null;
}

const goToDashboard = () => window.location.replace('/dashboard');

/* ------------------------------------------------------------------ login */
const loginForm = document.getElementById('login-form');
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(loginForm);
    const { email, password } = loginForm.elements;

    const errors = {};
    if (!email.value.trim()) errors.email = 'Email is required.';
    if (!password.value) errors.password = 'Password is required.';
    if (Object.keys(errors).length) return showErrors(loginForm, errors);

    const btn = document.getElementById('login-submit');
    setBusy(btn, true);
    try {
      await api('POST', '/auth/login', { email: email.value.trim(), password: password.value }, { redirectOn401: false });
      goToDashboard();
    } catch (err) {
      showErrors(loginForm, err.errors, err.errors ? null : err.message);
      setBusy(btn, false);
    }
  });
}

/* --------------------------------------------------------------- register */
const registerForm = document.getElementById('register-form');
if (registerForm) {
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(registerForm);
    const { name, email, password, confirm } = registerForm.elements;

    const errors = {};
    if (name.value.trim().length < 2) errors.name = 'Name must be at least 2 characters.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim())) errors.email = 'Enter a valid email address.';
    const pw = passwordProblem(password.value);
    if (pw) errors.password = pw;
    if (confirm.value !== password.value) errors.confirm = 'Passwords do not match.';
    if (Object.keys(errors).length) return showErrors(registerForm, errors);

    const btn = document.getElementById('register-submit');
    setBusy(btn, true);
    try {
      await api(
        'POST',
        '/auth/register',
        { name: name.value.trim(), email: email.value.trim(), password: password.value },
        { redirectOn401: false }
      );
      goToDashboard();
    } catch (err) {
      showErrors(registerForm, err.errors, err.errors ? null : err.message);
      setBusy(btn, false);
    }
  });
}

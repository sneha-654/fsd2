// Thin fetch wrapper for the JSON API. Cookies (httpOnly JWT) travel automatically.

export class ApiError extends Error {
  constructor(status, message, errors) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.errors = errors || null;
  }
}

/**
 * @param {string} method  HTTP verb
 * @param {string} path    path below /api, e.g. "/tasks?page=1"
 * @param {object} [body]  JSON body
 * @param {{redirectOn401?: boolean}} [opts]
 */
export async function api(method, path, body, { redirectOn401 = true } = {}) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method,
      credentials: 'same-origin',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (_) {
    throw new ApiError(0, 'Cannot reach the server. Check your connection and try again.');
  }

  if (res.status === 204) return null;

  let data = null;
  try {
    data = await res.json();
  } catch (_) {
    /* non-JSON body */
  }

  if (!res.ok) {
    if (res.status === 401 && redirectOn401) {
      window.location.replace('/login');
    }
    throw new ApiError(res.status, (data && data.error) || `Request failed (${res.status}).`, data && data.errors);
  }
  return data;
}

/** Builds a query string, skipping empty values. */
export function qs(params) {
  const sp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== '' && v !== null && v !== undefined) sp.set(k, String(v));
  });
  return sp.toString();
}

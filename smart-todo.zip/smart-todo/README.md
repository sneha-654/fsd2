# Smart To-Do List Management System

A full-stack task manager: **Node.js + Express** API, **MySQL** database, and a **vanilla HTML/CSS/JavaScript** frontend (no frameworks, no CDNs).

**Features:** register/login with bcrypt + JWT in an httpOnly cookie · per-user data · dashboard with counts, completion donut, last-7-days bars, priority breakdown and "Up next" · tasks with priority, due date, categories, checklists and daily/weekly/monthly repeats · search, filters, sorting, pagination · CSV export · dark mode · keyboard shortcuts (`n` new task, `/` search).

---

## 1. Install the prerequisites

### Node.js (v18.11 or newer, v20/22 recommended)
Download the LTS installer from <https://nodejs.org> and run it, then check:
```bash
node -v
npm -v
```

### MySQL (8.x recommended, 5.7+ works)
* **Windows / macOS:** download *MySQL Community Server* from <https://dev.mysql.com/downloads/mysql/> (during setup, note the `root` password you choose).
* **Ubuntu / Debian:** `sudo apt update && sudo apt install mysql-server && sudo systemctl start mysql`
* **macOS (Homebrew):** `brew install mysql && brew services start mysql`

Check that you can log in:
```bash
mysql -u root -p
```
(type `exit` to leave). If your root user has no password, just press Enter.

## 2. Create the database

Easiest way: let the project do it for you in step 5 (`npm run db:init` creates the `todo_management` database **and** all tables).

Prefer doing it by hand? Either of these works:
```bash
mysql -u root -p < database/schema.sql
```
or inside the MySQL shell: `CREATE DATABASE todo_management CHARACTER SET utf8mb4;` and then run `npm run db:init`.

## 3. Configure `.env`

```bash
cp .env.example .env          # Windows (cmd):  copy .env.example .env
```
Open `.env` and set at least:

| Variable | What to put |
|---|---|
| `DB_USER`, `DB_PASSWORD` | Your MySQL login (often `root` + the password from installation) |
| `JWT_SECRET` | A long random string. Generate one: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |

Every variable is explained inside `.env.example`. The server refuses to start while `JWT_SECRET` is still the example value.

## 4. Install dependencies
```bash
npm install
```

## 5. Create the tables
```bash
npm run db:init
```
You should see `Done. Tables: categories, subtasks, tasks, users`. It is safe to run again; it never deletes data. (`npm run db:reset` **drops the whole database** and recreates it empty.)

## 6. Start the app
```bash
npm start
```
Open **<http://localhost:3000>**, click *Create an account*, and you land on your dashboard. New accounts start with *Work*, *Personal* and *Study* categories.

Other scripts: `npm run dev` (auto-restart on file changes) · `npm test` (unit tests for validators, CSV, recurrence dates).

---

## Project structure

```
smart-todo/
├── frontend/
│   ├── login.html  register.html  dashboard.html
│   ├── css/   base.css  auth.css  dashboard.css
│   └── js/    theme.js  api.js  ui.js  auth.js  dashboard.js
├── backend/
│   ├── server.js                 app wiring: helmet CSP, routes, page guards
│   ├── config/    env.js  db.js  settings + mysql2 pool + transactions
│   ├── middleware/ auth.js  originCheck.js  rateLimit.js  errorHandler.js
│   ├── routes/    auth.js  tasks.js  categories.js  stats.js
│   ├── utils/     validators.js  taskQueries.js  csv.js  dates.js  ApiError.js  asyncHandler.js
│   └── tests/     utils.test.js
├── database/      schema.sql  init.js
├── .env.example  package.json  README.md
```

## REST API

All bodies are JSON. Errors look like `{ "error": "message", "errors": { "field": "message" } }`
(validation = **422**, bad id/JSON = 400, not logged in = 401, not yours / missing = 404, duplicate = 409, rate limited = 429).
State-changing requests must come from the app's own origin (see Security).

| Method & path | Purpose |
|---|---|
| `POST /api/auth/register` · `/login` · `/logout` | Create account, log in, log out |
| `GET /api/auth/me` | Current user |
| `PUT /api/auth/profile` | `{ name }` |
| `PUT /api/auth/password` | `{ currentPassword, newPassword }` (signs out other devices) |
| `GET /api/tasks` | Query: `q, priority, status (pending/completed), category (id or none), due (overdue/today/week/none), sort (due_date/priority/title/created), order, page, limit, today` |
| `POST /api/tasks` · `GET/PUT/DELETE /api/tasks/:id` | CRUD. Body: `title, description, priority, due_date, category_id, recurrence, subtasks[]` |
| `PATCH /api/tasks/:id/status` | `{ completed?: bool }` (toggles if omitted); creates the next occurrence for repeating tasks |
| `PATCH /api/tasks/:id/subtasks/:subId` | Toggle a checklist item |
| `GET /api/tasks/export` | CSV download; accepts the same filters as the list |
| `DELETE /api/tasks/completed` | Clear all completed tasks |
| `GET/POST /api/categories` · `PUT/DELETE /api/categories/:id` | Categories (deleting one keeps its tasks, uncategorised) |
| `GET /api/stats?today=YYYY-MM-DD&tz=minutes` | Counts, completion rate, last 7 days, priority breakdown, Up next |

## Security notes

* **Passwords:** bcrypt (cost 12), min 8 chars with a letter and a number. Login gives one generic error and does equal work for unknown emails.
* **Sessions:** JWT in an `httpOnly`, `SameSite=Lax` cookie (`Secure` in production). Changing your password invalidates tokens on other devices.
* **CSRF:** every POST/PUT/PATCH/DELETE must carry an `Origin` (or `Referer`) matching the server's host or `APP_ORIGIN`. If you test the API with curl, add `-H "Origin: http://localhost:3000"`.
* **Headers:** helmet with a strict CSP (`script-src 'self'`, `style-src 'self'`: no inline scripts or styles, no eval, no external hosts).
* **Rate limiting:** login/register are limited per IP (failed attempts only count for login).
* **SQL:** prepared statements only; every task/category/subtask query is scoped by `user_id`. Only whitelisted `ORDER BY` fragments and already-validated integers (`LIMIT/OFFSET`) are placed in SQL text.
* **Pages:** HTML is only served through routes, so `/dashboard` redirects to `/login` on the server when logged out (and `/login` redirects away when logged in).
* **CSV export** prefixes cells starting with `= + - @` (or tab/CR) with `'` so spreadsheets cannot run them as formulas.

## Behaviour worth knowing

* **Recurring tasks:** completing one creates the next (same title, priority, category, checklist reset, due date +1 day / +7 days / +1 month, clamped to month end). The completed task remembers its successor (`next_task_id`), so un-completing and re-completing never creates a duplicate. Repeating tasks require a due date.
* **"Today" and "overdue"** follow your browser's calendar day; the daily chart uses your UTC offset. Timestamps are stored in UTC.
* **Sorting** always lists open tasks before completed ones, then applies your chosen sort. "This week" means today through the coming Sunday.

## Troubleshooting

| Message | Fix |
|---|---|
| `JWT_SECRET is missing, too short...` | Set a 32+ character `JWT_SECRET` in `.env` (command in step 3). |
| `Cannot connect to MySQL...` / `ECONNREFUSED` | Start the MySQL service; check `DB_HOST` / `DB_PORT`. |
| `MySQL rejected the DB_USER / DB_PASSWORD` | Fix the credentials in `.env`. On MySQL 8 with a brand-new install, make sure the root password you set matches. |
| `Database ... is not initialised` | Run `npm run db:init`. |
| `Port 3000 already in use` | Change `PORT` in `.env`. |
| Logged out immediately on `http://` in production mode | Set `COOKIE_SECURE=false` (only for local testing) or serve over HTTPS. |

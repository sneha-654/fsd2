'use strict';

/**
 * Creates the database and tables from schema.sql.
 *   npm run db:init     create everything that is missing (safe to repeat)
 *   npm run db:reset    DROP the database first, then recreate it (deletes all data!)
 */

const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const mysql = require('mysql2/promise');

const reset = process.argv.includes('--reset');
const dbName = process.env.DB_NAME || 'todo_management';

function fail(message) {
  console.error(`\n[db] ${message}\n`);
  process.exit(1);
}

async function main() {
  if (!/^[A-Za-z0-9_]+$/.test(dbName)) {
    fail('DB_NAME may only contain letters, numbers and underscores.');
  }
  if (reset && process.env.NODE_ENV === 'production' && process.env.ALLOW_DB_RESET !== 'true') {
    fail('Refusing to reset a production database. Set ALLOW_DB_RESET=true to override.');
  }

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    charset: 'utf8mb4',
    multipleStatements: true, // only this setup script uses it; the web app never does
  });

  try {
    if (reset) {
      console.log(`[db] Dropping database "${dbName}" ...`);
      await connection.query(`DROP DATABASE IF EXISTS \`${dbName}\``);
    }

    const schema = fs
      .readFileSync(path.join(__dirname, 'schema.sql'), 'utf8')
      .replace(/todo_management/g, dbName);

    console.log(`[db] Applying schema to "${dbName}" ...`);
    await connection.query(schema);

    const [tables] = await connection.query(`SHOW TABLES FROM \`${dbName}\``);
    const names = tables.map((row) => Object.values(row)[0]);
    console.log(`[db] Done. Tables: ${names.join(', ')}`);
  } finally {
    await connection.end();
  }
}

main().catch((err) => {
  if (err.code === 'ECONNREFUSED') {
    fail(
      `Cannot connect to MySQL at ${process.env.DB_HOST || '127.0.0.1'}:${process.env.DB_PORT || 3306}.\n` +
        '     Make sure the MySQL server is installed and running.'
    );
  }
  if (err.code === 'ER_ACCESS_DENIED_ERROR') {
    fail('MySQL rejected DB_USER / DB_PASSWORD from your .env file.');
  }
  fail(err.message);
});

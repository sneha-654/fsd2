-- ===========================================================================
--  Smart To-Do List Management System: MySQL 5.7+ / 8.x schema
--  Run with:   npm run db:init      (or:  mysql -u root -p < database/schema.sql)
--  Safe to run repeatedly: every statement uses IF NOT EXISTS.
-- ===========================================================================

CREATE DATABASE IF NOT EXISTS todo_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE todo_management;

-- ---------------------------------------------------------------- users ----
CREATE TABLE IF NOT EXISTS users (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name           VARCHAR(100) NOT NULL,
  email          VARCHAR(255) NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  -- Incremented on password change; tokens carrying an older value are rejected.
  token_version  INT UNSIGNED NOT NULL DEFAULT 0,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------- categories ----
CREATE TABLE IF NOT EXISTS categories (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  name        VARCHAR(30)  NOT NULL,
  color       CHAR(7)      NOT NULL DEFAULT '#4263EB',
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  -- A user cannot have two categories with the same name.
  UNIQUE KEY uq_categories_user_name (user_id, name),
  CONSTRAINT fk_categories_user
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- tasks ----
CREATE TABLE IF NOT EXISTS tasks (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id       INT UNSIGNED NOT NULL,
  category_id   INT UNSIGNED NULL,
  title         VARCHAR(150) NOT NULL,
  description   TEXT NULL,
  priority      ENUM('High', 'Medium', 'Low') NOT NULL DEFAULT 'Medium',
  due_date      DATE NULL,
  is_completed  TINYINT(1) NOT NULL DEFAULT 0,
  completed_at  DATETIME NULL,                     -- stored in UTC
  recurrence    ENUM('none', 'daily', 'weekly', 'monthly') NOT NULL DEFAULT 'none',
  -- The occurrence generated when this task was completed. Prevents duplicates
  -- when a recurring task is toggled complete/pending repeatedly.
  next_task_id  INT UNSIGNED NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_tasks_user_status_due   (user_id, is_completed, due_date),
  KEY idx_tasks_user_priority     (user_id, priority),
  KEY idx_tasks_user_category     (user_id, category_id),
  KEY idx_tasks_user_completed_at (user_id, completed_at),
  KEY idx_tasks_user_created      (user_id, created_at),
  KEY idx_tasks_category          (category_id),
  KEY idx_tasks_next              (next_task_id),
  CONSTRAINT fk_tasks_user
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_tasks_category
    FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL,
  CONSTRAINT fk_tasks_next
    FOREIGN KEY (next_task_id) REFERENCES tasks (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------- subtasks ----
CREATE TABLE IF NOT EXISTS subtasks (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  task_id       INT UNSIGNED NOT NULL,
  title         VARCHAR(150) NOT NULL,
  is_completed  TINYINT(1) NOT NULL DEFAULT 0,
  sort_order    SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_subtasks_task_order (task_id, sort_order),
  CONSTRAINT fk_subtasks_task
    FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

'use strict';

const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');

const { config, assertRuntimeConfig } = require('./config/env');
const { pool, verifyDatabase } = require('./config/db');
const { loadUser, requirePageAuth, guestOnly } = require('./middleware/auth');
const originCheck = require('./middleware/originCheck');
const { notFound, errorHandler } = require('./middleware/errorHandler');
const asyncHandler = require('./utils/asyncHandler');

const authRoutes = require('./routes/auth');
const taskRoutes = require('./routes/tasks');
const categoryRoutes = require('./routes/categories');
const statsRoutes = require('./routes/stats');

const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', config.trustProxy);

  // Strict CSP: only our own files, no inline scripts, no inline styles, no eval.
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: false,
        directives: {
          'default-src': ["'self'"],
          'script-src': ["'self'"],
          'script-src-attr': ["'none'"],
          'style-src': ["'self'"],
          'img-src': ["'self'", 'data:'],
          'font-src': ["'self'"],
          'connect-src': ["'self'"],
          'object-src': ["'none'"],
          'base-uri': ["'self'"],
          'form-action': ["'self'"],
          'frame-ancestors': ["'none'"],
          ...(config.isProd ? { 'upgrade-insecure-requests': [] } : {}),
        },
      },
      strictTransportSecurity: config.isProd,
    })
  );

  app.use(cookieParser());
  app.use(express.json({ limit: '100kb' }));

  /* ------------------------------- API -------------------------------- */
  app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });
  app.use('/api', originCheck);
  app.use('/api/auth', authRoutes);
  app.use('/api/tasks', taskRoutes);
  app.use('/api/categories', categoryRoutes);
  app.use('/api/stats', statsRoutes);

  /* ------------------------ static assets & pages ---------------------- */
  // Only /css and /js are served as static files; the HTML pages go through
  // routes below so the server can decide who may see them.
  const staticOpts = { index: false, dotfiles: 'ignore', maxAge: config.isProd ? '1h' : 0 };
  app.use('/css', express.static(path.join(FRONTEND_DIR, 'css'), staticOpts));
  app.use('/js', express.static(path.join(FRONTEND_DIR, 'js'), staticOpts));

  const sendPage = (file) => (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.sendFile(path.join(FRONTEND_DIR, file));
  };

  app.get(
    '/',
    asyncHandler(async (req, res) => {
      const user = await loadUser(req);
      res.redirect(user ? '/dashboard' : '/login');
    })
  );
  app.get('/login', guestOnly, sendPage('login.html'));
  app.get('/register', guestOnly, sendPage('register.html'));
  app.get('/dashboard', requirePageAuth, sendPage('dashboard.html'));
  app.get(['/login.html', '/register.html', '/dashboard.html'], (req, res) =>
    res.redirect(req.path.replace(/\.html$/, ''))
  );

  app.use(notFound);
  app.use(errorHandler);
  return app;
}

async function start() {
  assertRuntimeConfig();
  await verifyDatabase();

  const app = createApp();
  const server = app.listen(config.port, () => {
    console.log(`Smart To-Do running at http://localhost:${config.port}  (${config.env})`);
  });

  const shutdown = (signal) => {
    console.log(`\n${signal} received, shutting down...`);
    server.close(async () => {
      await pool.end().catch(() => {});
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

if (require.main === module) {
  start().catch((err) => {
    console.error(`\nCould not start the server:\n${err.message}\n`);
    process.exit(1);
  });
}

module.exports = { createApp };

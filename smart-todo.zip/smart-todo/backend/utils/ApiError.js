'use strict';

/**
 * Error with an HTTP status that is safe to show to the client.
 * `errors` is an optional { field: message } map for validation failures.
 */
class ApiError extends Error {
  constructor(status, message, errors) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.errors = errors || null;
  }
}

module.exports = ApiError;

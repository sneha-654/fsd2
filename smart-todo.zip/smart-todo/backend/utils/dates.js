'use strict';

/**
 * Calendar-date helpers. Dates are plain "YYYY-MM-DD" strings (no time zone).
 * All arithmetic is done in UTC so daylight-saving changes can never shift a day.
 */

const pad = (n, len = 2) => String(n).padStart(len, '0');

/** Server-local today, used only when the client does not send its own date. */
function todayString() {
  const d = new Date();
  return `${pad(d.getFullYear(), 4)}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function isValidDateString(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

const toUtc = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d));
};

const fromUtc = (dt) =>
  `${pad(dt.getUTCFullYear(), 4)}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;

function addDays(s, n) {
  const dt = toUtc(s);
  dt.setUTCDate(dt.getUTCDate() + n);
  return fromUtc(dt);
}

/** Adds months and clamps the day (Jan 31 + 1 month = Feb 28/29). */
function addMonths(s, n) {
  const [y, m, d] = s.split('-').map(Number);
  const target = m - 1 + n;
  const ty = y + Math.floor(target / 12);
  const tm = ((target % 12) + 12) % 12;
  const lastDay = new Date(Date.UTC(ty, tm + 1, 0)).getUTCDate();
  return fromUtc(new Date(Date.UTC(ty, tm, Math.min(d, lastDay))));
}

/** The Sunday that ends the week containing `s` (returns `s` itself on a Sunday). */
function endOfWeek(s) {
  const dow = toUtc(s).getUTCDay(); // 0 = Sunday
  return addDays(s, (7 - dow) % 7);
}

/** Next due date of a recurring task, one step after `base`. */
function nextDueDate(base, recurrence) {
  switch (recurrence) {
    case 'daily':
      return addDays(base, 1);
    case 'weekly':
      return addDays(base, 7);
    case 'monthly':
      return addMonths(base, 1);
    default:
      throw new Error(`Unsupported recurrence: ${recurrence}`);
  }
}

module.exports = {
  todayString,
  isValidDateString,
  addDays,
  addMonths,
  endOfWeek,
  nextDueDate,
};

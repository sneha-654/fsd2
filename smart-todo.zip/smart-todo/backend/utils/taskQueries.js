'use strict';

/**
 * Shared SQL helpers for tasks. Every statement is a prepared statement with
 * bound parameters and always filters by user_id. The only values that are
 * interpolated into SQL text are:
 *   - ORDER BY fragments chosen from a fixed whitelist
 *   - LIMIT / OFFSET numbers that have already been validated as integers
 */

const ApiError = require('./ApiError');
const { endOfWeek } = require('./dates');

const TASK_COLUMNS = `
  t.id, t.title, t.description, t.priority, t.due_date, t.is_completed,
  t.completed_at, t.recurrence, t.next_task_id, t.created_at, t.updated_at,
  t.category_id, c.name AS category_name, c.color AS category_color`;

const TASK_FROM = `FROM tasks t LEFT JOIN categories c ON c.id = t.category_id AND c.user_id = t.user_id`;

const placeholders = (n) => Array(n).fill('?').join(',');

const toIso = (dt) => (dt ? `${String(dt).replace(' ', 'T')}Z` : null);

function serializeTask(row, subtasks = []) {
  const subs = subtasks.map((s) => ({
    id: s.id,
    title: s.title,
    is_completed: Boolean(s.is_completed),
  }));
  return {
    id: row.id,
    title: row.title,
    description: row.description || '',
    priority: row.priority,
    due_date: row.due_date || null,
    is_completed: Boolean(row.is_completed),
    completed_at: toIso(row.completed_at),
    recurrence: row.recurrence,
    category_id: row.category_id || null,
    category: row.category_id
      ? { id: row.category_id, name: row.category_name, color: row.category_color }
      : null,
    subtasks: subs,
    subtask_total: subs.length,
    subtask_done: subs.filter((s) => s.is_completed).length,
    created_at: toIso(row.created_at),
    updated_at: toIso(row.updated_at),
  };
}

/** Loads the subtasks for a set of task rows (one query) and serialises both. */
async function attachSubtasks(db, rows) {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const [subs] = await db.execute(
    `SELECT id, task_id, title, is_completed FROM subtasks
     WHERE task_id IN (${placeholders(ids.length)})
     ORDER BY sort_order ASC, id ASC`,
    ids
  );
  const byTask = new Map();
  subs.forEach((s) => {
    if (!byTask.has(s.task_id)) byTask.set(s.task_id, []);
    byTask.get(s.task_id).push(s);
  });
  return rows.map((r) => serializeTask(r, byTask.get(r.id) || []));
}

/** Fetches one task (with category and subtasks) owned by the user, or null. */
async function getTask(db, userId, taskId) {
  const [rows] = await db.execute(
    `SELECT ${TASK_COLUMNS} ${TASK_FROM} WHERE t.id = ? AND t.user_id = ?`,
    [taskId, userId]
  );
  if (rows.length === 0) return null;
  const [task] = await attachSubtasks(db, rows);
  return task;
}

async function getTaskOr404(db, userId, taskId) {
  const task = await getTask(db, userId, taskId);
  if (!task) throw new ApiError(404, 'Task not found.');
  return task;
}

const escapeLike = (s) => s.replace(/[\\%_]/g, (m) => `\\${m}`);

/** Builds the WHERE clause (and params) shared by the list and export endpoints. */
function buildFilter(userId, f) {
  const where = ['t.user_id = ?'];
  const params = [userId];

  if (f.q) {
    where.push('t.title LIKE ?');
    params.push(`%${escapeLike(f.q)}%`);
  }
  if (f.priority) {
    where.push('t.priority = ?');
    params.push(f.priority);
  }
  if (f.status === 'pending') where.push('t.is_completed = 0');
  if (f.status === 'completed') where.push('t.is_completed = 1');

  if (f.category === 'none') {
    where.push('t.category_id IS NULL');
  } else if (f.category) {
    where.push('t.category_id = ?');
    params.push(f.category);
  }

  switch (f.due) {
    case 'overdue':
      where.push('t.is_completed = 0 AND t.due_date < ?');
      params.push(f.today);
      break;
    case 'today':
      where.push('t.due_date = ?');
      params.push(f.today);
      break;
    case 'week':
      where.push('t.due_date BETWEEN ? AND ?');
      params.push(f.today, endOfWeek(f.today));
      break;
    case 'none':
      where.push('t.due_date IS NULL');
      break;
    default:
  }

  return { where: where.join(' AND '), params };
}

const SORT_SQL = {
  due_date: (dir) => `(t.due_date IS NULL) ASC, t.due_date ${dir}`,
  priority: (dir) => `FIELD(t.priority, 'High', 'Medium', 'Low') ${dir}`,
  title: (dir) => `t.title ${dir}`,
  created: (dir) => `t.created_at ${dir}`,
};

/** Open tasks always come before completed ones, then the chosen sort, then id as tie-breaker. */
function buildOrderBy(sort, order) {
  const dir = order === 'desc' ? 'DESC' : 'ASC';
  const key = SORT_SQL[sort] ? sort : 'due_date';
  return `t.is_completed ASC, ${SORT_SQL[key](dir)}, t.id DESC`;
}

/** Replaces a task's subtasks with `list` (update by id, insert new, delete missing). */
async function syncSubtasks(conn, taskId, list) {
  const [existing] = await conn.execute('SELECT id FROM subtasks WHERE task_id = ?', [taskId]);
  const existingIds = new Set(existing.map((r) => r.id));
  const keep = new Set(list.filter((s) => s.id && existingIds.has(s.id)).map((s) => s.id));

  for (const row of existing) {
    if (!keep.has(row.id)) {
      await conn.execute('DELETE FROM subtasks WHERE id = ? AND task_id = ?', [row.id, taskId]);
    }
  }
  let order = 0;
  for (const s of list) {
    const done = s.is_completed ? 1 : 0;
    if (s.id && existingIds.has(s.id)) {
      await conn.execute(
        'UPDATE subtasks SET title = ?, is_completed = ?, sort_order = ? WHERE id = ? AND task_id = ?',
        [s.title, done, order, s.id, taskId]
      );
    } else {
      await conn.execute(
        'INSERT INTO subtasks (task_id, title, is_completed, sort_order) VALUES (?, ?, ?, ?)',
        [taskId, s.title, done, order]
      );
    }
    order += 1;
  }
}

/** 422 unless the category exists and belongs to the user (null is fine). */
async function assertCategoryOwned(db, userId, categoryId) {
  if (categoryId === null || categoryId === undefined) return;
  const [rows] = await db.execute('SELECT id FROM categories WHERE id = ? AND user_id = ?', [
    categoryId,
    userId,
  ]);
  if (rows.length === 0) {
    throw new ApiError(422, 'Please fix the highlighted fields.', {
      category_id: 'That category does not exist.',
    });
  }
}

module.exports = {
  TASK_COLUMNS,
  TASK_FROM,
  placeholders,
  toIso,
  serializeTask,
  attachSubtasks,
  getTask,
  getTaskOr404,
  buildFilter,
  buildOrderBy,
  syncSubtasks,
  assertCategoryOwned,
};

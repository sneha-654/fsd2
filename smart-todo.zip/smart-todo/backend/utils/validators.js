'use strict';

const ApiError = require('./ApiError');
const { isValidDateString, todayString } = require('./dates');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const HEX_COLOR_RE = /^#[0-9a-fA-F]{6}$/;

const PRIORITIES = ['High', 'Medium', 'Low'];
const RECURRENCES = ['none', 'daily', 'weekly', 'monthly'];
const STATUSES = ['pending', 'completed'];
const DUE_FILTERS = ['overdue', 'today', 'week', 'none'];
const SORTS = ['due_date', 'priority', 'title', 'created'];
const ORDERS = ['asc', 'desc'];

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const text = (v) => (typeof v === 'string' ? v.trim() : '');
const isEmpty = (v) => v === undefined || v === null || v === '';

/** Throws a 422 ApiError with per-field messages, or returns the clean value. */
function check(result) {
  if (Object.keys(result.errors).length > 0) {
    throw new ApiError(422, 'Please fix the highlighted fields.', result.errors);
  }
  return result.value;
}

/** Parses a positive integer id from a URL segment. */
function parseId(raw, label = 'id') {
  if (typeof raw !== 'string' || !/^\d{1,10}$/.test(raw) || Number(raw) < 1) {
    throw new ApiError(400, `Invalid ${label}.`);
  }
  return Number(raw);
}

/* ------------------------------ users ---------------------------------- */

function passwordError(pw) {
  if (typeof pw !== 'string' || pw.length === 0) return 'Password is required.';
  if (pw.length < 8) return 'Password must be at least 8 characters.';
  // bcrypt only looks at the first 72 bytes; refuse longer input instead of silently truncating.
  if (Buffer.byteLength(pw, 'utf8') > 72) return 'Password must be at most 72 bytes long.';
  if (!/[A-Za-z]/.test(pw)) return 'Password must contain at least one letter.';
  if (!/\d/.test(pw)) return 'Password must contain at least one number.';
  return null;
}

function nameError(name) {
  if (!name) return 'Name is required.';
  if (name.length < 2) return 'Name must be at least 2 characters.';
  if (name.length > 100) return 'Name must be 100 characters or fewer.';
  return null;
}

function validateRegister(body) {
  const b = isObj(body) ? body : {};
  const errors = {};
  const name = text(b.name);
  const email = text(b.email).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';

  const nErr = nameError(name);
  if (nErr) errors.name = nErr;

  if (!email) errors.email = 'Email is required.';
  else if (email.length > 255 || !EMAIL_RE.test(email)) errors.email = 'Enter a valid email address.';

  const pErr = passwordError(password);
  if (pErr) errors.password = pErr;

  return { value: { name, email, password }, errors };
}

function validateLogin(body) {
  const b = isObj(body) ? body : {};
  const errors = {};
  const email = text(b.email).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';
  if (!email) errors.email = 'Email is required.';
  if (!password) errors.password = 'Password is required.';
  return { value: { email, password }, errors };
}

function validateProfile(body) {
  const b = isObj(body) ? body : {};
  const errors = {};
  const name = text(b.name);
  const nErr = nameError(name);
  if (nErr) errors.name = nErr;
  return { value: { name }, errors };
}

function validatePasswordChange(body) {
  const b = isObj(body) ? body : {};
  const errors = {};
  const currentPassword = typeof b.currentPassword === 'string' ? b.currentPassword : '';
  const newPassword = typeof b.newPassword === 'string' ? b.newPassword : '';

  if (!currentPassword) errors.currentPassword = 'Current password is required.';
  const pErr = passwordError(newPassword);
  if (pErr) errors.newPassword = pErr;
  else if (newPassword === currentPassword) {
    errors.newPassword = 'New password must be different from the current one.';
  }
  return { value: { currentPassword, newPassword }, errors };
}

/* ---------------------------- categories ------------------------------- */

function validateCategory(body) {
  const b = isObj(body) ? body : {};
  const errors = {};
  const name = text(b.name);
  let color = isEmpty(b.color) ? '#4263EB' : b.color;

  if (!name) errors.name = 'Category name is required.';
  else if (name.length > 30) errors.name = 'Category name must be 30 characters or fewer.';

  if (typeof color !== 'string' || !HEX_COLOR_RE.test(color)) {
    errors.color = 'Pick a valid color (e.g. #4263EB).';
  } else {
    color = color.toUpperCase();
  }
  return { value: { name, color }, errors };
}

/* ------------------------------- tasks --------------------------------- */

function validateTask(body) {
  const b = isObj(body) ? body : {};
  const errors = {};

  const title = text(b.title);
  if (!title) errors.title = 'Title is required.';
  else if (title.length > 150) errors.title = 'Title must be 150 characters or fewer.';

  let description = '';
  if (!isEmpty(b.description)) {
    if (typeof b.description !== 'string') errors.description = 'Description must be text.';
    else description = b.description.trim();
  }
  if (description.length > 2000) errors.description = 'Description must be 2000 characters or fewer.';

  const priority = isEmpty(b.priority) ? 'Medium' : b.priority;
  if (!PRIORITIES.includes(priority)) errors.priority = 'Priority must be High, Medium or Low.';

  let due_date = null;
  if (!isEmpty(b.due_date)) {
    if (!isValidDateString(b.due_date) || b.due_date < '2000-01-01' || b.due_date > '2100-12-31') {
      errors.due_date = 'Enter a valid due date.';
    } else {
      due_date = b.due_date;
    }
  }

  let category_id = null;
  if (!isEmpty(b.category_id)) {
    const raw = b.category_id;
    const ok = typeof raw === 'number' || (typeof raw === 'string' && /^\d+$/.test(raw));
    const n = ok ? Number(raw) : NaN;
    if (!Number.isInteger(n) || n < 1) errors.category_id = 'Choose a valid category.';
    else category_id = n;
  }

  const recurrence = isEmpty(b.recurrence) ? 'none' : b.recurrence;
  if (!RECURRENCES.includes(recurrence)) {
    errors.recurrence = 'Repeat must be none, daily, weekly or monthly.';
  } else if (recurrence !== 'none' && !due_date && !errors.due_date) {
    errors.recurrence = 'Recurring tasks need a due date.';
  }

  // `undefined` means "leave subtasks untouched" on update.
  let subtasks;
  if (b.subtasks !== undefined) {
    if (!Array.isArray(b.subtasks)) {
      errors.subtasks = 'Subtasks must be a list.';
    } else if (b.subtasks.length > 30) {
      errors.subtasks = 'A task can have at most 30 subtasks.';
    } else {
      subtasks = [];
      for (let i = 0; i < b.subtasks.length; i += 1) {
        const s = isObj(b.subtasks[i]) ? b.subtasks[i] : {};
        const t = text(s.title);
        if (!t) {
          errors.subtasks = `Subtask ${i + 1} needs a title.`;
          break;
        }
        if (t.length > 150) {
          errors.subtasks = `Subtask ${i + 1} is too long (max 150 characters).`;
          break;
        }
        subtasks.push({
          id: Number.isInteger(s.id) && s.id > 0 ? s.id : null,
          title: t,
          is_completed: s.is_completed === true,
        });
      }
    }
  }

  return {
    value: { title, description, priority, due_date, category_id, recurrence, subtasks },
    errors,
  };
}

function validateStatusBody(body) {
  const b = isObj(body) ? body : {};
  const errors = {};
  let completed;
  if (b.completed !== undefined) {
    if (typeof b.completed !== 'boolean') errors.completed = 'completed must be true or false.';
    else completed = b.completed;
  }
  let today = todayString();
  if (!isEmpty(b.today)) {
    if (!isValidDateString(b.today)) errors.today = 'today must be a valid YYYY-MM-DD date.';
    else today = b.today;
  }
  return { value: { completed, today }, errors };
}

function validateSubtaskBody(body) {
  const b = isObj(body) ? body : {};
  const errors = {};
  let completed;
  if (b.completed !== undefined) {
    if (typeof b.completed !== 'boolean') errors.completed = 'completed must be true or false.';
    else completed = b.completed;
  }
  return { value: { completed }, errors };
}

/** Validates list/export query-string filters. */
function parseTaskQuery(query) {
  const src = isObj(query) ? query : {};
  const errors = {};

  const get = (key) => {
    const v = src[key];
    if (v === undefined) return undefined;
    if (typeof v !== 'string') {
      errors[key] = 'Invalid value.';
      return undefined;
    }
    return v.trim();
  };
  const oneOf = (key, list) => {
    const v = get(key);
    if (v === undefined || v === '') return '';
    if (!list.includes(v)) {
      errors[key] = `Invalid ${key}.`;
      return '';
    }
    return v;
  };
  const int = (key, def, min, max) => {
    const v = get(key);
    if (v === undefined || v === '') return def;
    if (!/^\d{1,9}$/.test(v) || Number(v) < min || Number(v) > max) {
      errors[key] = `${key} must be a number between ${min} and ${max}.`;
      return def;
    }
    return Number(v);
  };

  const value = {};
  value.q = (get('q') || '').slice(0, 100);
  value.priority = oneOf('priority', PRIORITIES);
  value.status = oneOf('status', STATUSES);
  value.due = oneOf('due', DUE_FILTERS);
  value.sort = oneOf('sort', SORTS) || 'due_date';
  value.order = oneOf('order', ORDERS) || (value.sort === 'created' ? 'desc' : 'asc');

  const cat = get('category');
  if (!cat) value.category = '';
  else if (cat === 'none') value.category = 'none';
  else if (/^\d{1,10}$/.test(cat) && Number(cat) > 0) value.category = Number(cat);
  else {
    errors.category = 'Invalid category.';
    value.category = '';
  }

  value.page = int('page', 1, 1, 100000);
  value.limit = int('limit', 9, 1, 50);

  const today = get('today');
  if (today === undefined || today === '') value.today = todayString();
  else if (!isValidDateString(today)) {
    errors.today = 'today must be a valid YYYY-MM-DD date.';
    value.today = todayString();
  } else value.today = today;

  return { value, errors };
}

function validateStatsQuery(query) {
  const src = isObj(query) ? query : {};
  const errors = {};
  let today = todayString();
  let tz = 0;

  if (!isEmpty(src.today)) {
    if (typeof src.today !== 'string' || !isValidDateString(src.today)) {
      errors.today = 'today must be a valid YYYY-MM-DD date.';
    } else today = src.today;
  }
  if (!isEmpty(src.tz)) {
    const n = typeof src.tz === 'string' && /^-?\d{1,4}$/.test(src.tz) ? Number(src.tz) : NaN;
    if (!Number.isInteger(n) || n < -840 || n > 840) errors.tz = 'tz must be a UTC offset in minutes.';
    else tz = n;
  }
  return { value: { today, tz }, errors };
}

module.exports = {
  PRIORITIES,
  RECURRENCES,
  check,
  parseId,
  passwordError,
  validateRegister,
  validateLogin,
  validateProfile,
  validatePasswordChange,
  validateCategory,
  validateTask,
  validateStatusBody,
  validateSubtaskBody,
  parseTaskQuery,
  validateStatsQuery,
};

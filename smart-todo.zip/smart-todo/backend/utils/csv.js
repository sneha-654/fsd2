'use strict';

/**
 * CSV helpers with protection against CSV (formula) injection.
 *
 * Spreadsheet apps execute cells that start with = + - @ (or tab / carriage
 * return). We neutralise those by prefixing a single quote, then apply normal
 * RFC 4180 quoting.
 */

const FORMULA_START = /^(?:[\t\r]|\s*[=+\-@])/;

function escapeCell(value) {
  if (value === null || value === undefined) return '';
  let s = String(value);
  if (FORMULA_START.test(s)) s = `'${s}`;
  if (/[",\r\n]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}

/** @param {string[]} headers  @param {Array<Array<*>>} rows */
function toCsv(headers, rows) {
  const lines = [headers, ...rows].map((r) => r.map(escapeCell).join(','));
  return lines.join('\r\n') + '\r\n';
}

module.exports = { toCsv, escapeCell };

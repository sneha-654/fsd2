'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const dates = require('../utils/dates');
const { toCsv, escapeCell } = require('../utils/csv');
const v = require('../utils/validators');
const ApiError = require('../utils/ApiError');

/* ------------------------------- dates -------------------------------- */

test('addDays crosses month and year boundaries', () => {
  assert.equal(dates.addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(dates.addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(dates.addDays('2028-02-28', 1), '2028-02-29');
});

test('addMonths clamps to the last day of the month', () => {
  assert.equal(dates.addMonths('2026-01-31', 1), '2026-02-28');
  assert.equal(dates.addMonths('2028-01-31', 1), '2028-02-29');
  assert.equal(dates.addMonths('2026-12-15', 1), '2027-01-15');
  assert.equal(dates.addMonths('2026-03-31', -1), '2026-02-28');
});

test('nextDueDate handles every recurrence type', () => {
  assert.equal(dates.nextDueDate('2026-11-10', 'daily'), '2026-11-11');
  assert.equal(dates.nextDueDate('2026-11-10', 'weekly'), '2026-11-17');
  assert.equal(dates.nextDueDate('2026-11-30', 'monthly'), '2026-12-30');
  assert.throws(() => dates.nextDueDate('2026-11-10', 'none'));
});

test('endOfWeek returns the coming Sunday (or the same day on Sunday)', () => {
  assert.equal(dates.endOfWeek('2026-11-10'), '2026-11-15'); // Tuesday
  assert.equal(dates.endOfWeek('2026-11-15'), '2026-11-15'); // Sunday
  assert.equal(dates.endOfWeek('2026-11-16'), '2026-11-22'); // Monday
});

test('isValidDateString rejects impossible dates', () => {
  assert.equal(dates.isValidDateString('2026-02-29'), false);
  assert.equal(dates.isValidDateString('2028-02-29'), true);
  assert.equal(dates.isValidDateString('2026-13-01'), false);
  assert.equal(dates.isValidDateString('26-1-1'), false);
  assert.equal(dates.isValidDateString(20261110), false);
});

/* -------------------------------- csv --------------------------------- */

test('csv neutralises formula injection', () => {
  assert.equal(escapeCell('=HYPERLINK("http://evil")'), `"'=HYPERLINK(""http://evil"")"`);
  assert.equal(escapeCell('+1+1'), "'+1+1");
  assert.equal(escapeCell('-2+3'), "'-2+3");
  assert.equal(escapeCell('@SUM(A1)'), "'@SUM(A1)");
  assert.equal(escapeCell('\tcmd'), "'\tcmd");
  assert.equal(escapeCell('  =1+1'), "'  =1+1");
});

test('csv quotes commas, quotes and newlines; leaves plain text alone', () => {
  assert.equal(escapeCell('Buy milk'), 'Buy milk');
  assert.equal(escapeCell('a,b'), '"a,b"');
  assert.equal(escapeCell('say "hi"'), '"say ""hi"""');
  assert.equal(escapeCell('line1\nline2'), '"line1\nline2"');
  assert.equal(escapeCell(null), '');
  assert.equal(escapeCell(7), '7');
});

test('toCsv joins rows with CRLF', () => {
  assert.equal(toCsv(['A', 'B'], [['1', 'x,y']]), 'A,B\r\n1,"x,y"\r\n');
});

/* ----------------------------- validators ----------------------------- */

const errorsOf = (fn) => {
  try {
    fn();
    return null;
  } catch (e) {
    assert.ok(e instanceof ApiError);
    assert.equal(e.status, 422);
    return e.errors;
  }
};

test('password rules: min 8 chars with a letter and a number', () => {
  assert.equal(v.passwordError('abc12'), 'Password must be at least 8 characters.');
  assert.match(v.passwordError('abcdefgh'), /number/);
  assert.match(v.passwordError('12345678'), /letter/);
  assert.equal(v.passwordError('abcdefg1'), null);
  assert.match(v.passwordError('a1' + 'x'.repeat(80)), /72/);
});

test('register: per-field errors and normalisation', () => {
  const errs = errorsOf(() => v.check(v.validateRegister({ name: '', email: 'nope', password: 'short' })));
  assert.ok(errs.name && errs.email && errs.password);

  const ok = v.check(v.validateRegister({ name: '  Sneha ', email: ' Sneha@Example.COM ', password: 'abcdefg1' }));
  assert.equal(ok.name, 'Sneha');
  assert.equal(ok.email, 'sneha@example.com');
});

test('task: title required, enums checked, recurrence needs a due date', () => {
  const errs = errorsOf(() => v.check(v.validateTask({ title: ' ', priority: 'Urgent', due_date: '2026-02-30', recurrence: 'yearly' })));
  assert.ok(errs.title && errs.priority && errs.due_date && errs.recurrence);

  const noDue = errorsOf(() => v.check(v.validateTask({ title: 'x', recurrence: 'daily' })));
  assert.match(noDue.recurrence, /due date/);

  const ok = v.check(
    v.validateTask({
      title: ' Pay rent ',
      description: '  monthly ',
      due_date: '2026-11-30',
      category_id: '4',
      recurrence: 'monthly',
      subtasks: [{ title: ' a ', is_completed: true }, { id: 9, title: 'b' }],
    })
  );
  assert.equal(ok.title, 'Pay rent');
  assert.equal(ok.priority, 'Medium');
  assert.equal(ok.category_id, 4);
  assert.deepEqual(ok.subtasks, [
    { id: null, title: 'a', is_completed: true },
    { id: 9, title: 'b', is_completed: false },
  ]);
});

test('task: subtasks omitted means "unchanged" (undefined), blank subtask title rejected', () => {
  assert.equal(v.check(v.validateTask({ title: 'x' })).subtasks, undefined);
  const errs = errorsOf(() => v.check(v.validateTask({ title: 'x', subtasks: [{ title: '  ' }] })));
  assert.match(errs.subtasks, /Subtask 1/);
});

test('category: color must be a 6-digit hex', () => {
  assert.ok(errorsOf(() => v.check(v.validateCategory({ name: 'A', color: 'red' }))).color);
  assert.equal(v.check(v.validateCategory({ name: 'A', color: '#abcdef' })).color, '#ABCDEF');
  assert.equal(v.check(v.validateCategory({ name: 'A' })).color, '#4263EB');
});

test('query parsing: defaults, whitelist, and rejection of junk', () => {
  const d = v.check(v.parseTaskQuery({ today: '2026-11-10' }));
  assert.equal(d.sort, 'due_date');
  assert.equal(d.order, 'asc');
  assert.equal(d.limit, 9);
  assert.equal(d.page, 1);

  assert.equal(v.check(v.parseTaskQuery({ sort: 'created' })).order, 'desc');
  assert.equal(v.check(v.parseTaskQuery({ category: 'none' })).category, 'none');
  assert.equal(v.check(v.parseTaskQuery({ category: '12' })).category, 12);

  const errs = errorsOf(() =>
    v.check(v.parseTaskQuery({ sort: 'id; DROP TABLE tasks', limit: '999', due: 'later', q: ['a', 'b'] }))
  );
  assert.ok(errs.sort && errs.limit && errs.due && errs.q);
});

test('parseId only accepts positive integers', () => {
  assert.equal(v.parseId('42'), 42);
  for (const bad of ['0', '-1', '1.5', 'abc', '1 OR 1=1', '', undefined]) {
    assert.throws(() => v.parseId(bad), (e) => e instanceof ApiError && e.status === 400);
  }
});

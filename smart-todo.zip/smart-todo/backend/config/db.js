'use strict';

const mysql = require('mysql2/promise');
const { config } = require('./env');

/**
 * Shared connection pool.
 *  - utf8mb4 everywhere
 *  - DATE / DATETIME values come back as strings ("2026-11-10") so there is
 *    no accidental time-zone shifting in JavaScript
 *  - every connection runs in UTC, so stored timestamps are UTC
 */
const pool = mysql.createPool({
  host: config.db.host,
  port: config.db.port,
  user: config.db.user,
  password: config.db.password,
  database: config.db.database,
  waitForConnections: true,
  connectionLimit: config.db.connectionLimit,
  queueLimit: 0,
  charset: 'utf8mb4',
  timezone: 'Z',
  dateStrings: true,
});

pool.pool.on('connection', (conn) => {
  conn.query("SET time_zone = '+00:00'");
});

/** Runs `fn(connection)` inside a transaction; commits on success, rolls back on error. */
async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    try {
      await conn.rollback();
    } catch (_) {
      /* connection already broken; nothing else to do */
    }
    throw err;
  } finally {
    conn.release();
  }
}

/** Verifies the database is reachable and the schema exists. */
async function verifyDatabase() {
  try {
    await pool.query('SELECT 1 FROM users LIMIT 1');
    await pool.query('SELECT 1 FROM tasks LIMIT 1');
    await pool.query('SELECT 1 FROM subtasks LIMIT 1');
    await pool.query('SELECT 1 FROM categories LIMIT 1');
  } catch (err) {
    if (err.code === 'ER_NO_SUCH_TABLE' || err.code === 'ER_BAD_DB_ERROR') {
      throw new Error(
        `Database "${config.db.database}" is not initialised. Run:  npm run db:init`
      );
    }
    if (err.code === 'ECONNREFUSED') {
      throw new Error(
        `Cannot connect to MySQL at ${config.db.host}:${config.db.port}. Is the MySQL server running?`
      );
    }
    if (err.code === 'ER_ACCESS_DENIED_ERROR') {
      throw new Error('MySQL rejected the DB_USER / DB_PASSWORD from your .env file.');
    }
    throw err;
  }
}

module.exports = { pool, withTransaction, verifyDatabase };

'use strict';

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env') });

function int(name, fallback, { min = -Infinity, max = Infinity } = {}) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new Error(`Invalid ${name} in .env: expected an integer between ${min} and ${max}.`);
  }
  return n;
}

const nodeEnv = process.env.NODE_ENV || 'development';
const isProd = nodeEnv === 'production';

const cookieSecureRaw = (process.env.COOKIE_SECURE || '').toLowerCase();

const config = {
  env: nodeEnv,
  isProd,
  port: int('PORT', 3000, { min: 1, max: 65535 }),
  appOrigins: (process.env.APP_ORIGIN || '')
    .split(',')
    .map((s) => s.trim().replace(/\/+$/, ''))
    .filter(Boolean),
  trustProxy: int('TRUST_PROXY', 0, { min: 0, max: 10 }),
  db: {
    host: process.env.DB_HOST || '127.0.0.1',
    port: int('DB_PORT', 3306, { min: 1, max: 65535 }),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'todo_management',
    connectionLimit: int('DB_CONNECTION_LIMIT', 10, { min: 1, max: 100 }),
  },
  jwt: {
    secret: process.env.JWT_SECRET || '',
    expiresDays: int('JWT_EXPIRES_DAYS', 7, { min: 1, max: 365 }),
  },
  cookieSecure: cookieSecureRaw === '' ? isProd : cookieSecureRaw === 'true',
  bcryptRounds: int('BCRYPT_ROUNDS', 12, { min: 4, max: 15 }),
  authRateLimit: {
    windowMs: int('AUTH_RATE_LIMIT_WINDOW_MINUTES', 15, { min: 1, max: 1440 }) * 60 * 1000,
    max: int('AUTH_RATE_LIMIT_MAX', 10, { min: 1, max: 10000 }),
  },
};

/** Called once at server start-up; fails fast with a helpful message. */
function assertRuntimeConfig() {
  const s = config.jwt.secret;
  if (!s || s.length < 32 || /change-me/i.test(s)) {
    throw new Error(
      'JWT_SECRET is missing, too short (< 32 chars) or still the example value.\n' +
        'Generate one and put it in your .env file:\n' +
        "  node -e \"console.log(require('crypto').randomBytes(48).toString('hex'))\""
    );
  }
  if (!/^[A-Za-z0-9_]+$/.test(config.db.database)) {
    throw new Error('DB_NAME may only contain letters, numbers and underscores.');
  }
}

module.exports = { config, assertRuntimeConfig };

'use strict';

const rateLimit = require('express-rate-limit');
const { config } = require('../config/env');

/** Brute-force protection for login and register. Successful logins are not counted. */
const authLimiter = rateLimit({
  windowMs: config.authRateLimit.windowMs,
  limit: config.authRateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  handler: (req, res) => {
    res.status(429).json({
      error: 'Too many attempts. Please wait a few minutes and try again.',
    });
  },
});

module.exports = { authLimiter };

'use strict';

const ApiError = require('../utils/ApiError');

/** 404 for anything not matched by a route. */
function notFound(req, res, next) {
  if (req.path.startsWith('/api')) return next(new ApiError(404, 'Endpoint not found.'));
  return res.status(404).type('text/plain').send('Page not found');
}

/** Central error handler: turns every error into a consistent JSON response. */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);

  let status = 500;
  const body = { error: 'Something went wrong on our side. Please try again.' };

  if (err instanceof ApiError) {
    status = err.status;
    body.error = err.message;
    if (err.errors) body.errors = err.errors;
  } else if (err.type === 'entity.parse.failed') {
    status = 400;
    body.error = 'Malformed JSON in request body.';
  } else if (err.type === 'entity.too.large') {
    status = 413;
    body.error = 'Request body is too large.';
  } else if (err.code === 'ER_DUP_ENTRY') {
    status = 409;
    body.error = 'That record already exists.';
  }

  if (status >= 500) console.error(`[error] ${req.method} ${req.originalUrl}`, err);
  return res.status(status).json(body);
}

module.exports = { notFound, errorHandler };

'use strict';

const { config } = require('../config/env');
const ApiError = require('../utils/ApiError');

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

function originOf(url) {
  try {
    return new URL(url).origin;
  } catch (_) {
    return null;
  }
}

/**
 * CSRF protection by Origin check (in addition to the SameSite=Lax cookie).
 *
 * Every state-changing request must carry an Origin (or, failing that, Referer)
 * header whose host matches the host this server was reached on, or one of the
 * origins listed in APP_ORIGIN. Browsers always send Origin on cross-site POSTs
 * and scripts cannot forge it.
 */
function originCheck(req, res, next) {
  if (SAFE_METHODS.has(req.method)) return next();

  const origin = req.get('origin');
  let source;
  if (origin) source = origin === 'null' ? null : originOf(origin);
  else source = originOf(req.get('referer') || '');

  if (!source) {
    return next(new ApiError(403, 'Request blocked: missing or invalid Origin header.'));
  }

  const sameHost = new URL(source).host === req.get('host');
  if (sameHost || config.appOrigins.includes(source)) return next();

  return next(new ApiError(403, 'Request blocked: cross-site request.'));
}

module.exports = originCheck;

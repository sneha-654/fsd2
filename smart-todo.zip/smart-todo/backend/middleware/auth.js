'use strict';

const jwt = require('jsonwebtoken');
const { config } = require('../config/env');
const { pool } = require('../config/db');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const COOKIE_NAME = 'token';

const cookieBase = () => ({
  httpOnly: true, // not readable from JavaScript
  sameSite: 'lax', // not sent on cross-site POSTs
  secure: config.cookieSecure,
  path: '/',
});

function signToken(user) {
  return jwt.sign({ sub: String(user.id), tv: user.token_version }, config.jwt.secret, {
    algorithm: 'HS256',
    expiresIn: `${config.jwt.expiresDays}d`,
  });
}

function setAuthCookie(res, user) {
  res.cookie(COOKIE_NAME, signToken(user), {
    ...cookieBase(),
    maxAge: config.jwt.expiresDays * 24 * 60 * 60 * 1000,
  });
}

function clearAuthCookie(res) {
  res.clearCookie(COOKIE_NAME, cookieBase());
}

/**
 * Resolves the logged-in user from the cookie, or null.
 * The user is re-read from the database on every request, so deleted users and
 * tokens issued before a password change stop working immediately.
 */
async function loadUser(req) {
  const token = req.cookies && req.cookies[COOKIE_NAME];
  if (!token || typeof token !== 'string') return null;

  let payload;
  try {
    payload = jwt.verify(token, config.jwt.secret, { algorithms: ['HS256'] });
  } catch (_) {
    return null;
  }
  const id = Number(payload.sub);
  if (!Number.isInteger(id) || id < 1) return null;

  const [rows] = await pool.execute(
    'SELECT id, name, email, token_version FROM users WHERE id = ?',
    [id]
  );
  const user = rows[0];
  if (!user || user.token_version !== payload.tv) return null;
  return user;
}

/** API guard: 401 JSON when not logged in. */
const requireAuth = asyncHandler(async (req, res, next) => {
  const user = await loadUser(req);
  if (!user) {
    clearAuthCookie(res);
    throw new ApiError(401, 'Please log in to continue.');
  }
  req.user = user;
  next();
});

/** Page guard: server-side redirect to /login when not logged in. */
const requirePageAuth = asyncHandler(async (req, res, next) => {
  const user = await loadUser(req);
  if (!user) {
    if (req.cookies && req.cookies[COOKIE_NAME]) clearAuthCookie(res);
    return res.redirect('/login');
  }
  req.user = user;
  return next();
});

/** Login / register pages: bounce already-logged-in users to the dashboard. */
const guestOnly = asyncHandler(async (req, res, next) => {
  const user = await loadUser(req);
  if (user) return res.redirect('/dashboard');
  return next();
});

module.exports = {
  loadUser,
  requireAuth,
  requirePageAuth,
  guestOnly,
  setAuthCookie,
  clearAuthCookie,
};

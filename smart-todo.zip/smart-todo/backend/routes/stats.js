'use strict';

const express = require('express');
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { addDays } = require('../utils/dates');
const { check, validateStatsQuery } = require('../utils/validators');
const { TASK_FROM } = require('../utils/taskQueries');

const router = express.Router();
router.use(requireAuth);

router.get(
  '/',
  asyncHandler(async (req, res) => {
    // The browser sends its own calendar date and UTC offset, so "today",
    // "overdue" and the daily chart follow the user's clock, not the server's.
    const { today, tz } = check(validateStatsQuery(req.query));
    const userId = req.user.id;

    const [[t]] = await pool.execute(
      `SELECT
         COUNT(*) AS total,
         COALESCE(SUM(is_completed = 1), 0) AS completed,
         COALESCE(SUM(is_completed = 0), 0) AS pending,
         COALESCE(SUM(is_completed = 0 AND due_date < ?), 0) AS overdue,
         COALESCE(SUM(is_completed = 0 AND due_date = ?), 0) AS due_today
       FROM tasks WHERE user_id = ?`,
      [today, today, userId]
    );
    const totals = {
      total: Number(t.total),
      completed: Number(t.completed),
      pending: Number(t.pending),
      overdue: Number(t.overdue),
      dueToday: Number(t.due_today),
    };
    const completionRate = totals.total ? Math.round((totals.completed / totals.total) * 100) : 0;

    // Completed per local day for the last 7 days (oldest first, zero-filled).
    const [dayRows] = await pool.execute(
      `SELECT DATE(DATE_ADD(completed_at, INTERVAL ? MINUTE)) AS d, COUNT(*) AS cnt
       FROM tasks
       WHERE user_id = ? AND is_completed = 1 AND completed_at IS NOT NULL
         AND completed_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 9 DAY)
       GROUP BY d`,
      [tz, userId]
    );
    const perDay = new Map(dayRows.map((r) => [String(r.d), Number(r.cnt)]));
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = addDays(today, i - 6);
      return { date, count: perDay.get(date) || 0 };
    });

    const [prioRows] = await pool.execute(
      `SELECT priority, COUNT(*) AS total, COALESCE(SUM(is_completed = 1), 0) AS completed
       FROM tasks WHERE user_id = ? GROUP BY priority`,
      [userId]
    );
    const priority = { High: { total: 0, completed: 0 }, Medium: { total: 0, completed: 0 }, Low: { total: 0, completed: 0 } };
    prioRows.forEach((r) => {
      priority[r.priority] = { total: Number(r.total), completed: Number(r.completed) };
    });

    const [upRows] = await pool.execute(
      `SELECT t.id, t.title, t.priority, t.due_date,
              c.name AS category_name, c.color AS category_color
       ${TASK_FROM}
       WHERE t.user_id = ? AND t.is_completed = 0 AND t.due_date IS NOT NULL
       ORDER BY t.due_date ASC, FIELD(t.priority, 'High', 'Medium', 'Low') ASC, t.id ASC
       LIMIT 5`,
      [userId]
    );
    const upNext = upRows.map((r) => ({
      id: r.id,
      title: r.title,
      priority: r.priority,
      due_date: r.due_date,
      category: r.category_name ? { name: r.category_name, color: r.category_color } : null,
    }));

    res.json({ totals, completionRate, last7Days, priority, upNext });
  })
);

module.exports = router;

'use strict';

const express = require('express');
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { check, parseId, validateCategory } = require('../utils/validators');

const router = express.Router();
router.use(requireAuth);

const MAX_CATEGORIES = 30;

const duplicateName = () =>
  new ApiError(409, 'Please fix the highlighted fields.', {
    name: 'You already have a category with this name.',
  });

async function listCategories(userId) {
  const [rows] = await pool.execute(
    `SELECT c.id, c.name, c.color, COUNT(t.id) AS task_count
     FROM categories c
     LEFT JOIN tasks t ON t.category_id = c.id AND t.user_id = c.user_id
     WHERE c.user_id = ?
     GROUP BY c.id, c.name, c.color
     ORDER BY c.name ASC`,
    [userId]
  );
  return rows.map((r) => ({ ...r, task_count: Number(r.task_count) }));
}

router.get(
  '/',
  asyncHandler(async (req, res) => {
    res.json({ categories: await listCategories(req.user.id) });
  })
);

router.post(
  '/',
  asyncHandler(async (req, res) => {
    const { name, color } = check(validateCategory(req.body));

    const [[{ total }]] = await pool.execute(
      'SELECT COUNT(*) AS total FROM categories WHERE user_id = ?',
      [req.user.id]
    );
    if (total >= MAX_CATEGORIES) {
      throw new ApiError(422, `You can have at most ${MAX_CATEGORIES} categories.`, {
        name: `Limit of ${MAX_CATEGORIES} categories reached.`,
      });
    }

    let id;
    try {
      const [result] = await pool.execute(
        'INSERT INTO categories (user_id, name, color) VALUES (?, ?, ?)',
        [req.user.id, name, color]
      );
      id = result.insertId;
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw duplicateName();
      throw err;
    }
    res.status(201).json({ category: { id, name, color, task_count: 0 } });
  })
);

router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    const { name, color } = check(validateCategory(req.body));

    const [existing] = await pool.execute('SELECT id FROM categories WHERE id = ? AND user_id = ?', [
      id,
      req.user.id,
    ]);
    if (existing.length === 0) throw new ApiError(404, 'Category not found.');

    try {
      await pool.execute('UPDATE categories SET name = ?, color = ? WHERE id = ? AND user_id = ?', [
        name,
        color,
        id,
        req.user.id,
      ]);
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw duplicateName();
      throw err;
    }
    const category = (await listCategories(req.user.id)).find((c) => c.id === id);
    res.json({ category });
  })
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    // Tasks keep existing: the foreign key sets their category_id to NULL.
    const [result] = await pool.execute('DELETE FROM categories WHERE id = ? AND user_id = ?', [
      id,
      req.user.id,
    ]);
    if (result.affectedRows === 0) throw new ApiError(404, 'Category not found.');
    res.status(204).end();
  })
);

module.exports = router;

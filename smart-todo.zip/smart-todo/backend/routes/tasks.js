'use strict';

const express = require('express');
const { pool, withTransaction } = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { toCsv } = require('../utils/csv');
const { nextDueDate } = require('../utils/dates');
const {
  check,
  parseId,
  validateTask,
  validateStatusBody,
  validateSubtaskBody,
  parseTaskQuery,
} = require('../utils/validators');
const {
  TASK_COLUMNS,
  TASK_FROM,
  toIso,
  attachSubtasks,
  getTask,
  getTaskOr404,
  buildFilter,
  buildOrderBy,
  syncSubtasks,
  assertCategoryOwned,
} = require('../utils/taskQueries');

const router = express.Router();
router.use(requireAuth);

const EXPORT_ROW_LIMIT = 5000;

/* ------------------------------ list ----------------------------------- */

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const f = check(parseTaskQuery(req.query));
    const { where, params } = buildFilter(req.user.id, f);

    const [[{ total }]] = await pool.execute(
      `SELECT COUNT(*) AS total FROM tasks t WHERE ${where}`,
      params
    );
    const totalPages = Math.max(1, Math.ceil(total / f.limit));
    const page = Math.min(f.page, totalPages);
    const offset = (page - 1) * f.limit; // integers only: validated above

    const [rows] = await pool.execute(
      `SELECT ${TASK_COLUMNS} ${TASK_FROM}
       WHERE ${where}
       ORDER BY ${buildOrderBy(f.sort, f.order)}
       LIMIT ${f.limit} OFFSET ${offset}`,
      params
    );

    res.json({
      tasks: await attachSubtasks(pool, rows),
      pagination: { page, limit: f.limit, total, totalPages },
    });
  })
);

/* ----------------------------- export CSV ------------------------------ */

router.get(
  '/export',
  asyncHandler(async (req, res) => {
    const f = check(parseTaskQuery(req.query));
    const { where, params } = buildFilter(req.user.id, f);

    const [rows] = await pool.execute(
      `SELECT ${TASK_COLUMNS} ${TASK_FROM}
       WHERE ${where}
       ORDER BY ${buildOrderBy(f.sort, f.order)}
       LIMIT ${EXPORT_ROW_LIMIT}`,
      params
    );
    const tasks = await attachSubtasks(pool, rows);

    const headers = [
      'Title',
      'Description',
      'Priority',
      'Status',
      'Category',
      'Due date',
      'Repeats',
      'Subtasks done',
      'Created (UTC)',
      'Completed (UTC)',
    ];
    const data = tasks.map((t) => [
      t.title,
      t.description,
      t.priority,
      t.is_completed ? 'Completed' : 'Pending',
      t.category ? t.category.name : '',
      t.due_date || '',
      t.recurrence === 'none' ? '' : t.recurrence,
      t.subtask_total ? `${t.subtask_done}/${t.subtask_total}` : '',
      t.created_at || '',
      t.completed_at || '',
    ]);

    res.set({
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="tasks-${f.today}.csv"`,
      'Cache-Control': 'no-store',
    });
    // The BOM makes Excel read the file as UTF-8.
    res.send(`\uFEFF${toCsv(headers, data)}`);
  })
);

/* -------------------------- clear completed ---------------------------- */

router.delete(
  '/completed',
  asyncHandler(async (req, res) => {
    const [result] = await pool.execute('DELETE FROM tasks WHERE user_id = ? AND is_completed = 1', [
      req.user.id,
    ]);
    res.json({ deleted: result.affectedRows });
  })
);

/* ------------------------------ create --------------------------------- */

router.post(
  '/',
  asyncHandler(async (req, res) => {
    const v = check(validateTask(req.body));
    await assertCategoryOwned(pool, req.user.id, v.category_id);

    const id = await withTransaction(async (conn) => {
      const [result] = await conn.execute(
        `INSERT INTO tasks (user_id, category_id, title, description, priority, due_date, recurrence)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          req.user.id,
          v.category_id,
          v.title,
          v.description || null,
          v.priority,
          v.due_date,
          v.recurrence,
        ]
      );
      await syncSubtasks(conn, result.insertId, v.subtasks || []);
      return result.insertId;
    });

    res.status(201).json({ task: await getTask(pool, req.user.id, id) });
  })
);

/* ------------------------------ read one ------------------------------- */

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    res.json({ task: await getTaskOr404(pool, req.user.id, id) });
  })
);

/* ------------------------------ update --------------------------------- */

router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    const v = check(validateTask(req.body));
    await assertCategoryOwned(pool, req.user.id, v.category_id);

    await withTransaction(async (conn) => {
      const [rows] = await conn.execute(
        'SELECT id FROM tasks WHERE id = ? AND user_id = ? FOR UPDATE',
        [id, req.user.id]
      );
      if (rows.length === 0) throw new ApiError(404, 'Task not found.');

      await conn.execute(
        `UPDATE tasks
         SET category_id = ?, title = ?, description = ?, priority = ?, due_date = ?, recurrence = ?
         WHERE id = ? AND user_id = ?`,
        [
          v.category_id,
          v.title,
          v.description || null,
          v.priority,
          v.due_date,
          v.recurrence,
          id,
          req.user.id,
        ]
      );
      if (v.subtasks !== undefined) await syncSubtasks(conn, id, v.subtasks);
    });

    res.json({ task: await getTask(pool, req.user.id, id) });
  })
);

/* ------------------------------ delete --------------------------------- */

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    const [result] = await pool.execute('DELETE FROM tasks WHERE id = ? AND user_id = ?', [
      id,
      req.user.id,
    ]);
    if (result.affectedRows === 0) throw new ApiError(404, 'Task not found.');
    res.status(204).end();
  })
);

/* ------------------- mark completed / pending (+ recurrence) ------------ */

router.patch(
  '/:id/status',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    const { completed, today } = check(validateStatusBody(req.body));

    const nextTaskId = await withTransaction(async (conn) => {
      // Row lock: two quick toggles can never both create a "next" task.
      const [rows] = await conn.execute(
        'SELECT * FROM tasks WHERE id = ? AND user_id = ? FOR UPDATE',
        [id, req.user.id]
      );
      if (rows.length === 0) throw new ApiError(404, 'Task not found.');
      const task = rows[0];

      const target = completed === undefined ? !task.is_completed : completed;
      if (target === Boolean(task.is_completed)) return null; // already in that state

      if (!target) {
        await conn.execute(
          'UPDATE tasks SET is_completed = 0, completed_at = NULL WHERE id = ? AND user_id = ?',
          [id, req.user.id]
        );
        return null;
      }

      await conn.execute(
        'UPDATE tasks SET is_completed = 1, completed_at = UTC_TIMESTAMP() WHERE id = ? AND user_id = ?',
        [id, req.user.id]
      );

      // Recurring: create the next occurrence once. next_task_id remembers it, so
      // completing -> reopening -> completing again never produces a duplicate.
      if (task.recurrence !== 'none' && !task.next_task_id) {
        const dueBase = task.due_date || today;
        const [inserted] = await conn.execute(
          `INSERT INTO tasks (user_id, category_id, title, description, priority, due_date, recurrence)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            task.user_id,
            task.category_id,
            task.title,
            task.description,
            task.priority,
            nextDueDate(dueBase, task.recurrence),
            task.recurrence,
          ]
        );
        await conn.execute(
          `INSERT INTO subtasks (task_id, title, is_completed, sort_order)
           SELECT ?, title, 0, sort_order FROM subtasks WHERE task_id = ?`,
          [inserted.insertId, id]
        );
        await conn.execute('UPDATE tasks SET next_task_id = ? WHERE id = ? AND user_id = ?', [
          inserted.insertId,
          id,
          req.user.id,
        ]);
        return inserted.insertId;
      }
      return null;
    });

    res.json({
      task: await getTask(pool, req.user.id, id),
      next_task: nextTaskId ? await getTask(pool, req.user.id, nextTaskId) : null,
    });
  })
);

/* --------------------------- toggle a subtask -------------------------- */

router.patch(
  '/:id/subtasks/:subId',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    const subId = parseId(req.params.subId, 'subtask id');
    const { completed } = check(validateSubtaskBody(req.body));

    const [rows] = await pool.execute(
      `SELECT s.id, s.is_completed
       FROM subtasks s JOIN tasks t ON t.id = s.task_id
       WHERE s.id = ? AND s.task_id = ? AND t.user_id = ?`,
      [subId, id, req.user.id]
    );
    if (rows.length === 0) throw new ApiError(404, 'Subtask not found.');

    const next = completed === undefined ? !rows[0].is_completed : completed;
    await pool.execute('UPDATE subtasks SET is_completed = ? WHERE id = ? AND task_id = ?', [
      next ? 1 : 0,
      subId,
      id,
    ]);

    res.json({ task: await getTaskOr404(pool, req.user.id, id) });
  })
);

module.exports = router;

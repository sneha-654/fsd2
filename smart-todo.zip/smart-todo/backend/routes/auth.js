'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');
const { config } = require('../config/env');
const { pool, withTransaction } = require('../config/db');
const { requireAuth, setAuthCookie, clearAuthCookie } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimit');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const {
  check,
  validateRegister,
  validateLogin,
  validateProfile,
  validatePasswordChange,
} = require('../utils/validators');

const router = express.Router();

const DEFAULT_CATEGORIES = [
  { name: 'Work', color: '#4263EB' },
  { name: 'Personal', color: '#D6336C' },
  { name: 'Study', color: '#0CA678' },
];

// Compared against when the email is unknown, so response time does not reveal which emails exist.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password-1', config.bcryptRounds);

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email });

router.post(
  '/register',
  authLimiter,
  asyncHandler(async (req, res) => {
    const { name, email, password } = check(validateRegister(req.body));
    const passwordHash = await bcrypt.hash(password, config.bcryptRounds);

    let user;
    try {
      user = await withTransaction(async (conn) => {
        const [result] = await conn.execute(
          'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)',
          [name, email, passwordHash]
        );
        const userId = result.insertId;
        for (const c of DEFAULT_CATEGORIES) {
          await conn.execute('INSERT INTO categories (user_id, name, color) VALUES (?, ?, ?)', [
            userId,
            c.name,
            c.color,
          ]);
        }
        return { id: userId, name, email, token_version: 0 };
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        throw new ApiError(409, 'Please fix the highlighted fields.', {
          email: 'An account with this email already exists.',
        });
      }
      throw err;
    }

    setAuthCookie(res, user);
    res.status(201).json({ user: publicUser(user) });
  })
);

router.post(
  '/login',
  authLimiter,
  asyncHandler(async (req, res) => {
    const { email, password } = check(validateLogin(req.body));

    const [rows] = await pool.execute(
      'SELECT id, name, email, password_hash, token_version FROM users WHERE email = ?',
      [email]
    );
    const user = rows[0];
    const passwordOk = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);

    // One generic message for "no such user" and "wrong password".
    if (!user || !passwordOk) throw new ApiError(401, 'Invalid email or password.');

    setAuthCookie(res, user);
    res.json({ user: publicUser(user) });
  })
);

router.post('/logout', (req, res) => {
  clearAuthCookie(res);
  res.json({ message: 'Logged out.' });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

router.put(
  '/profile',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { name } = check(validateProfile(req.body));
    await pool.execute('UPDATE users SET name = ? WHERE id = ?', [name, req.user.id]);
    res.json({ user: publicUser({ ...req.user, name }) });
  })
);

router.put(
  '/password',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = check(validatePasswordChange(req.body));

    const [rows] = await pool.execute('SELECT password_hash FROM users WHERE id = ?', [
      req.user.id,
    ]);
    const matches = rows[0] && (await bcrypt.compare(currentPassword, rows[0].password_hash));
    if (!matches) {
      throw new ApiError(422, 'Please fix the highlighted fields.', {
        currentPassword: 'Current password is incorrect.',
      });
    }

    const newHash = await bcrypt.hash(newPassword, config.bcryptRounds);
    // Bumping token_version signs out every other session that holds an older token.
    await pool.execute(
      'UPDATE users SET password_hash = ?, token_version = token_version + 1 WHERE id = ?',
      [newHash, req.user.id]
    );
    setAuthCookie(res, { ...req.user, token_version: req.user.token_version + 1 });
    res.json({ message: 'Password updated. Other devices have been signed out.' });
  })
);

module.exports = router;
